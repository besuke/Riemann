//! R entry point of rmql. Only conversions are here: the calculations are in the `rmql`
//! crate. Dates are QuantLib serial numbers; `R/dates.R` converts them from and to R dates.
//! Vector functions return their results as named columns, with NA and a message in `error`
//! where a row fails, so that R decides whether to stop.
//!
//! Expected errors of inputs and calculations are returned as values: a list with `failure`
//! holds the message, and `R/common.R` turns it into an R error. They do not use the `Err` path
//! of extendr, which unwinds through a panic. A panic therefore always means a defect here or in
//! the core; the process's panic hook is left alone, so it stays visible and can be diagnosed.
use extendr_api::prelude::*;
use rmql::american_approximations::{self, AmericanApproximation};
use rmql::asset_swap::{self, FutureBasisTerms, OisAssetSwapTerms, YenBasisTerms};
use rmql::batch::{self, BondEvaluation, CurveEvaluation};
use rmql::bond_curve::{self, BondCurve, BondCurveInterpolation, BondCurveQuote, BondCurveSpec};
use rmql::cashflow_analysis::{self, YieldConvention, YieldSolver};
use rmql::cashflows::CashFlow;
use rmql::cds::{self, Cds, CdsCurve, CdsCurveSpec, CdsQuote, CdsQuoteType, CdsSpec, CdsValue, HazardCurve};
use rmql::hull_white::{
    self, CalibrationInstrument, CalibrationQuote, CalibrationSettings, CallableFlow, GridSettings, HullWhite, Quadrature,
    SwaptionFlows,
};
use rmql::instruments::{FixedRateBond, FixedRateBondSpec};
use rmql::longstaff_schwartz::{
    self, CalibrationPaths, FewInTheMoney, LongstaffSchwartzSettings, PathSequence,
};
use rmql::math::sobol::SobolSequence;
use rmql::lmm::{self, CapletTerms};
use rmql::credit_risk;
use rmql::market_risk;
use rmql::mbs::{self, Amortization, PassThroughTerms, RatePaths};
use rmql::interest_rate::{Compounding, InterestRate};
use rmql::curves::{CurveInput, LogDiscountInterpolation, YieldCurve};
use rmql::fx_smile;
use rmql::names;
use rmql::ois::{OisCurve, OisCurveInstrument, OisCurveSpec};
use rmql::ois_swap::{self, Fixings, OisSwap, OisSwapSpec};
use rmql::options::{self, Greeks, MonteCarloSettings, OptionInputs};
use rmql::portfolio::{self, OptimalPortfolio, PortfolioConstraints, PortfolioMethod, ReturnMatrix};
use rmql::prdc::{self, PrdcMonteCarlo, PrdcSensitivity, PrdcTerms};
use rmql::risk;
use rmql::sabr::{self, SabrParameters};
use rmql::time::{Date, HolidayCalendar, ScheduleSpec};
use rmql::tranche;
use rmql::trs;
use rmql::irrbb;
use rmql::yen_bond;
use rmql::xccy::{bootstrap_xccy_curve as bootstrap_xccy_curve_core, ResettingLeg, XccyCurve, XccyCurveSpec, XccyInstrument, XccyLeg};
type Core<T> = std::result::Result<T, rmql::Error>;
fn failure(e: rmql::Error) -> List {
    list!(failure = e.to_string())
}
/// A list of the results, or the failure of the whole call.
fn outcome(result: Core<List>) -> List {
    result.unwrap_or_else(failure)
}
fn date(serial: i32) -> Core<Date> {
    Date::from_serial(serial as i64)
}
/// 0 stands for no date.
fn optional_date(serial: i32) -> Core<Option<Date>> {
    if serial == 0 {
        Ok(None)
    } else {
        date(serial).map(Some)
    }
}
/// A logical column crosses the border as integers. R has checked it; anything but 0 and 1 (NA
/// included) is a failure here too, and never reads as false.
fn flag(value: i32) -> Core<bool> {
    match value {
        0 => Ok(false),
        1 => Ok(true),
        other => Err(rmql::Error::InvalidInput {
            reason: format!("a logical value must be TRUE or FALSE, not {other}"),
        }),
    }
}
fn na_real() -> f64 {
    <f64 as CanBeNA>::na()
}
/// Splits row results into values, with NA for errors, and messages, empty for values.
fn split_rows(rows: Vec<Core<f64>>) -> (Vec<f64>, Vec<String>) {
    let mut values = Vec::with_capacity(rows.len());
    let mut errors = Vec::with_capacity(rows.len());
    for row in rows {
        match row {
            Ok(v) => {
                values.push(v);
                errors.push(String::new());
            }
            Err(e) => {
                values.push(na_real());
                errors.push(e.to_string());
            }
        }
    }
    (values, errors)
}
fn value_list(rows: Vec<Core<f64>>) -> List {
    let (value, error) = split_rows(rows);
    list!(value = value, error = error)
}
fn yield_convention(day_count: &str, compounding: &str, frequency: i32) -> Core<YieldConvention> {
    Ok(YieldConvention {
        day_count: names::parse_day_count(day_count)?,
        compounding: names::parse_compounding(compounding)?,
        frequency: frequency as u32,
    })
}
// ---- bonds ----------------------------------------------------------------------------------
#[extendr]
#[allow(clippy::too_many_arguments)]
fn create_fixed_rate_bond(
    settlement_days: i32,
    face_amount: f64,
    effective_date: i32,
    termination_date: i32,
    tenor: &str,
    calendar: &str,
    convention: &str,
    termination_convention: &str,
    rule: &str,
    end_of_month: bool,
    first_date: i32,
    next_to_last_date: i32,
    coupon_rate: Vec<f64>,
    day_count: &str,
    payment_convention: &str,
    redemption: f64,
    issue_date: i32,
    notionals: Vec<f64>,
) -> List {
    let build = || -> Core<FixedRateBond> {
        let notionals = if notionals.is_empty() { vec![face_amount] } else { notionals };
        FixedRateBond::with_schedules(FixedRateBondSpec {
            settlement_days: settlement_days as u32,
            face_amount,
            schedule: ScheduleSpec {
                effective_date: date(effective_date)?,
                termination_date: date(termination_date)?,
                tenor: names::parse_period(tenor)?,
                calendar: HolidayCalendar::from(names::parse_calendar(calendar)?),
                convention: names::parse_business_day_convention(convention)?,
                termination_convention: names::parse_business_day_convention(termination_convention)?,
                rule: names::parse_date_generation_rule(rule)?,
                end_of_month,
                first_date: optional_date(first_date)?,
                next_to_last_date: optional_date(next_to_last_date)?,
            },
            coupon_rate: coupon_rate.first().copied().unwrap_or(f64::NAN),
            day_count: names::parse_day_count(day_count)?,
            payment_convention: names::parse_business_day_convention(payment_convention)?,
            redemption,
            issue_date: optional_date(issue_date)?,
            payment_calendar: None,
        }, coupon_rate, notionals)
    };
    outcome(build().map(|bond| list!(value = ExternalPtr::new(bond))))
}
#[extendr]
fn compute_settlement_date(bond: ExternalPtr<FixedRateBond>, evaluation_date: Vec<i32>) -> List {
    let rows = evaluation_date
        .iter()
        .map(|&d| Ok(bond.settlement_date(date(d)?)?.serial() as f64))
        .collect();
    value_list(rows)
}
/// All measures of a bond at each yield and settlement date.
#[extendr]
fn compute_bond_values(
    bond: ExternalPtr<FixedRateBond>,
    rate: Vec<f64>,
    day_count: &str,
    compounding: &str,
    frequency: i32,
    settlement_date: Vec<i32>,
) -> List {
    outcome(bond_values_rows(
        &bond,
        &rate,
        day_count,
        compounding,
        frequency,
        &settlement_date,
    ))
}
fn bond_values_rows(
    bond: &FixedRateBond,
    rate: &[f64],
    day_count: &str,
    compounding: &str,
    frequency: i32,
    settlement_date: &[i32],
) -> Core<List> {
    let convention = yield_convention(day_count, compounding, frequency)?;
    let n = rate.len();
    let mut columns: [Vec<f64>; 9] = Default::default();
    let mut errors = vec![String::new(); n];
    let kinds = [
        names::parse_duration_type("simple")?,
        names::parse_duration_type("modified")?,
        names::parse_duration_type("macaulay")?,
    ];
    // the Macaulay duration exists only for compounded yields; elsewhere its column is NA, which
    // is not a failure of the row. `duration` reports it as an error when it is asked for.
    let has_macaulay = convention.compounding == Compounding::Compounded;
    for i in 0..n {
        let inputs = date(settlement_date[i]).and_then(|s| Ok((s, convention.rate(rate[i])?)));
        let (settlement, y) = match inputs {
            Ok(values) => values,
            Err(e) => {
                columns.iter_mut().for_each(|c| c.push(na_real()));
                errors[i] = e.to_string();
                continue;
            }
        };
        let values: [Core<f64>; 9] = [
            bond.clean_price(&y, settlement),
            bond.dirty_price(&y, settlement),
            bond.accrued_amount(settlement),
            bond.duration(&y, kinds[0], settlement),
            bond.duration(&y, kinds[1], settlement),
            if has_macaulay {
                bond.duration(&y, kinds[2], settlement)
            } else {
                Ok(na_real())
            },
            bond.convexity(&y, settlement),
            bond.basis_point_value(&y, settlement),
            bond.yield_value_basis_point(&y, settlement),
        ];
        for (column, value) in columns.iter_mut().zip(values) {
            match value {
                Ok(v) => column.push(v),
                Err(e) => {
                    column.push(na_real());
                    if errors[i].is_empty() {
                        errors[i] = e.to_string();
                    }
                }
            }
        }
    }
    let [clean_price, dirty_price, accrued_amount, duration_simple, duration_modified, duration_macaulay, convexity, basis_point_value, yield_value_basis_point] =
        columns;
    Ok(list!(
        clean_price = clean_price,
        dirty_price = dirty_price,
        accrued_amount = accrued_amount,
        duration_simple = duration_simple,
        duration_modified = duration_modified,
        duration_macaulay = duration_macaulay,
        convexity = convexity,
        basis_point_value = basis_point_value,
        yield_value_basis_point = yield_value_basis_point,
        error = errors
    ))
}
/// One duration measure at each yield and settlement date.
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_duration(
    bond: ExternalPtr<FixedRateBond>,
    rate: Vec<f64>,
    day_count: &str,
    compounding: &str,
    frequency: i32,
    settlement_date: Vec<i32>,
    duration_type: &str,
) -> List {
    let rows = || -> Core<List> {
        let convention = yield_convention(day_count, compounding, frequency)?;
        let kind = names::parse_duration_type(duration_type)?;
        let rows = rate
            .iter()
            .zip(&settlement_date)
            .map(|(&r, &s)| bond.duration(&convention.rate(r)?, kind, date(s)?))
            .collect();
        Ok(value_list(rows))
    };
    outcome(rows())
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_yield_from_price(
    bond: ExternalPtr<FixedRateBond>,
    price: Vec<f64>,
    price_type: &str,
    day_count: &str,
    compounding: &str,
    frequency: i32,
    settlement_date: Vec<i32>,
    accuracy: f64,
    max_iterations: i32,
    guess: f64,
) -> List {
    let rows = || -> Core<List> {
        let convention = yield_convention(day_count, compounding, frequency)?;
        let kind = names::parse_price_type(price_type)?;
        let solver = YieldSolver {
            accuracy,
            max_iterations: max_iterations as usize,
            guess,
        };
        let rows = price
            .iter()
            .zip(&settlement_date)
            .map(|(&p, &s)| bond.yield_from_price(p, kind, &convention, date(s)?, solver))
            .collect();
        Ok(value_list(rows))
    };
    outcome(rows())
}
#[extendr]
fn compute_ois_swap_dates(index: &str, evaluation_date: Vec<i32>, tenor: Vec<String>, settlement_days: i32) -> List {
    let run = || -> Core<List> {
        let index = names::parse_overnight_index(index)?;
        let settlement_days = u32::try_from(settlement_days)
            .map_err(|_| rmql::Error::InvalidInput { reason: format!("settlement_days must not be negative ({settlement_days})") })?;
        let rows: Vec<Core<rmql::ois::OisSwapDates>> = evaluation_date
            .iter()
            .zip(&tenor)
            .map(|(&d, t)| Ok(rmql::ois::compute_ois_swap_dates(&index, date(d)?, names::parse_period(t)?, settlement_days)?.0))
            .collect();
        let column = |pick: fn(&rmql::ois::OisSwapDates) -> rmql::Date| -> List {
            value_list(rows.iter().map(|r| r.as_ref().map(|d| f64::from(pick(d).serial())).map_err(Clone::clone)).collect())
        };
        Ok(list!(
            effective = column(|d| d.effective_date),
            termination = column(|d| d.termination_date),
            maturity = column(|d| d.maturity_date)
        ))
    };
    run().unwrap_or_else(failure)
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn create_ois_swap(
    side: &str,
    nominal: f64,
    effective_date: i32,
    termination_date: i32,
    index: &str,
    fixed_rate: f64,
    fixed_day_count: &str,
    spread: f64,
    fixed_frequency: i32,
    overnight_frequency: i32,
    payment_lag: i32,
) -> List {
    let build = || -> Core<OisSwap> {
        ois_swap::create_ois_swap(OisSwapSpec {
            side: names::parse_swap_side(side)?,
            nominal,
            effective_date: date(effective_date)?,
            termination_date: date(termination_date)?,
            index: names::parse_overnight_index(index)?,
            fixed_rate,
            fixed_day_count: if fixed_day_count.is_empty() { None } else { Some(names::parse_day_count(fixed_day_count)?) },
            spread,
            fixed_frequency: fixed_frequency as u32,
            overnight_frequency: overnight_frequency as u32,
            payment_lag: payment_lag as u32,
        })
    };
    match build() {
        Ok(swap) => list!(value = ExternalPtr::new(swap)),
        Err(e) => failure(e),
    }
}
/// Fixings cross the border as two columns of equal length.
fn fixings_of(dates: &[i32], rates: &[f64]) -> Core<Fixings> {
    dates.iter().zip(rates).map(|(&d, &r)| Ok((date(d)?, r))).collect()
}
/// The forecasting curve must be of the swap's index. Any curve can discount.
fn check_forecast(swap: &OisSwap, curve: &OisCurve) -> Core<()> {
    if swap.spec.index == curve.spec.index {
        Ok(())
    } else {
        Err(rmql::Error::InvalidInput { reason: "the curve is not of the swap's overnight index".into() })
    }
}
#[extendr]
fn compute_ois_swap_value(
    swap: ExternalPtr<OisSwap>,
    curve: ExternalPtr<OisCurve>,
    discount_curve: ExternalPtr<OisCurve>,
    evaluation_date: i32,
    fixing_dates: Vec<i32>,
    fixing_rates: Vec<f64>,
) -> List {
    let run = || -> Core<List> {
        check_forecast(&swap, &curve)?;
        let fixings = fixings_of(&fixing_dates, &fixing_rates)?;
        let v = ois_swap::compute_ois_swap_value(&*swap, &curve.curve, &discount_curve.curve, date(evaluation_date)?, &fixings)?;
        Ok(list!(
            npv = v.npv,
            fixed_leg_npv = v.fixed_leg_npv,
            overnight_leg_npv = v.overnight_leg_npv,
            fixed_leg_bps = v.fixed_leg_bps,
            overnight_leg_bps = v.overnight_leg_bps,
            fair_rate = v.fair_rate.unwrap_or_else(na_real),
            fair_spread = v.fair_spread.unwrap_or_else(na_real)
        ))
    };
    outcome(run())
}
/// The coupons of both legs. A coupon that cannot be computed has NA and its message.
#[extendr]
fn compute_ois_swap_cashflows(
    swap: ExternalPtr<OisSwap>,
    curve: ExternalPtr<OisCurve>,
    evaluation_date: i32,
    fixing_dates: Vec<i32>,
    fixing_rates: Vec<f64>,
) -> List {
    let run = || -> Core<List> {
        check_forecast(&swap, &curve)?;
        let fixings = fixings_of(&fixing_dates, &fixing_rates)?;
        let evaluation = date(evaluation_date)?;
        let n = swap.fixed_leg.len() + swap.overnight_leg.len();
        let (mut leg, mut payment_date) = (Vec::with_capacity(n), Vec::with_capacity(n));
        let (mut accrual_start, mut accrual_end) = (Vec::with_capacity(n), Vec::with_capacity(n));
        let mut amounts = Vec::with_capacity(n);
        for c in &swap.fixed_leg {
            leg.push("fixed".to_string());
            payment_date.push(c.payment_date.serial());
            accrual_start.push(c.accrual_start.serial());
            accrual_end.push(c.accrual_end.serial());
            amounts.push(c.amount());
        }
        for c in &swap.overnight_leg {
            leg.push("overnight".to_string());
            payment_date.push(c.payment_date.serial());
            accrual_start.push(c.accrual_start.serial());
            accrual_end.push(c.accrual_end.serial());
            amounts.push(ois_swap::compute_overnight_coupon_amount(&*swap, c, &curve.curve, evaluation, &fixings));
        }
        let (amount, error) = split_rows(amounts);
        Ok(list!(
            leg = leg,
            payment_date = payment_date,
            accrual_start = accrual_start,
            accrual_end = accrual_end,
            amount = amount,
            error = error
        ))
    };
    outcome(run())
}
#[extendr]
fn compute_ois_swap_daily_rates(
    swap: ExternalPtr<OisSwap>,
    curve: ExternalPtr<OisCurve>,
    coupon: i32,
    evaluation_date: i32,
    fixing_dates: Vec<i32>,
    fixing_rates: Vec<f64>,
) -> List {
    let run = || -> Core<List> {
        check_forecast(&swap, &curve)?;
        let fixings = fixings_of(&fixing_dates, &fixing_rates)?;
        let Some(c) = (coupon as usize).checked_sub(1).and_then(|i| swap.overnight_leg.get(i)) else {
            return Err(rmql::Error::InvalidInput {
                reason: format!("coupon {coupon} is outside the {} overnight coupons", swap.overnight_leg.len()),
            });
        };
        let days = ois_swap::compute_ois_swap_daily_rates(c, &curve.curve, date(evaluation_date)?, &fixings)?;
        Ok(list!(
            fixing_date = days.iter().map(|d| d.fixing_date.serial()).collect::<Vec<i32>>(),
            next_date = days.iter().map(|d| d.next_date.serial()).collect::<Vec<i32>>(),
            day_fraction = days.iter().map(|d| d.day_fraction).collect::<Vec<f64>>(),
            fixing = days.iter().map(|d| d.fixing.unwrap_or_else(na_real)).collect::<Vec<f64>>(),
            forward_rate = days.iter().map(|d| d.forward_rate).collect::<Vec<f64>>(),
            applied_rate = days.iter().map(|d| d.applied_rate).collect::<Vec<f64>>()
        ))
    };
    outcome(run())
}
#[extendr]
fn compute_ois_swap_quote_sensitivity(
    swap: ExternalPtr<OisSwap>,
    curve: ExternalPtr<OisCurve>,
    evaluation_date: i32,
    fixing_dates: Vec<i32>,
    fixing_rates: Vec<f64>,
) -> List {
    let run = || -> Core<List> {
        check_forecast(&swap, &curve)?;
        let fixings = fixings_of(&fixing_dates, &fixing_rates)?;
        let rows = ois_swap::compute_ois_swap_quote_sensitivity(&swap, &curve, date(evaluation_date)?, &fixings)?;
        Ok(list!(
            instrument = rows.iter().map(|r| r.instrument as i32 + 1).collect::<Vec<i32>>(),
            pillar_date = rows.iter().map(|r| r.pillar_date.serial()).collect::<Vec<i32>>(),
            rate = rows.iter().map(|r| r.quote).collect::<Vec<f64>>(),
            d_npv = rows.iter().map(|r| r.d_npv).collect::<Vec<f64>>()
        ))
    };
    outcome(run())
}
/// The cash flows of a bond in date order, coupons before a redemption on the same date.
#[extendr]
fn get_bond_cashflows(bond: ExternalPtr<FixedRateBond>) -> List {
    let rows = || -> Core<List> {
        let n = bond.cashflows.len();
        let mut payment_date = Vec::with_capacity(n);
        let mut amount = Vec::with_capacity(n);
        let mut kind = Vec::with_capacity(n);
        let mut accrual_start = Vec::with_capacity(n);
        let mut accrual_end = Vec::with_capacity(n);
        for flow in &bond.cashflows {
            payment_date.push(flow.date().serial() as i32);
            amount.push(flow.amount()?);
            match flow {
                CashFlow::FixedRateCoupon(c) => {
                    kind.push("coupon".to_string());
                    accrual_start.push(c.accrual_start.serial() as i32);
                    accrual_end.push(c.accrual_end.serial() as i32);
                }
                CashFlow::Redemption { .. } => {
                    kind.push("redemption".to_string());
                    accrual_start.push(0);
                    accrual_end.push(0);
                }
            }
        }
        Ok(list!(
            payment_date = payment_date,
            amount = amount,
            kind = kind,
            accrual_start = accrual_start,
            accrual_end = accrual_end
        ))
    };
    outcome(rows())
}
#[extendr]
fn compute_bond_value_with_zero_spread(
    bond: ExternalPtr<FixedRateBond>,
    curve: ExternalPtr<OisCurve>,
    spread: Vec<f64>,
    compounding: &str,
    frequency: i32,
    evaluation_date: Vec<i32>,
) -> List {
    let rows = || -> Core<List> {
        let compounding = names::parse_compounding(compounding)?;
        let n = spread.len();
        let (mut npv, mut settlement_value) = (Vec::with_capacity(n), Vec::with_capacity(n));
        let (mut dirty_price, mut clean_price) = (Vec::with_capacity(n), Vec::with_capacity(n));
        let mut errors = Vec::with_capacity(n);
        for (&s, &d) in spread.iter().zip(&evaluation_date) {
            let value = date(d).and_then(|d| {
                bond.value_with_zero_spread(&curve.curve, s, compounding, frequency as u32, d)
            });
            match value {
                Ok(v) => {
                    npv.push(v.npv);
                    settlement_value.push(v.settlement_value);
                    dirty_price.push(v.dirty_price);
                    clean_price.push(v.clean_price);
                    errors.push(String::new());
                }
                Err(e) => {
                    npv.push(na_real());
                    settlement_value.push(na_real());
                    dirty_price.push(na_real());
                    clean_price.push(na_real());
                    errors.push(e.to_string());
                }
            }
        }
        Ok(list!(
            npv = npv,
            settlement_value = settlement_value,
            dirty_price = dirty_price,
            clean_price = clean_price,
            error = errors
        ))
    };
    outcome(rows())
}
#[extendr]
fn compute_z_spread_from_price(
    bond: ExternalPtr<FixedRateBond>,
    curve: ExternalPtr<OisCurve>,
    price: Vec<f64>,
    price_type: &str,
    compounding: &str,
    frequency: i32,
    settlement_date: Vec<i32>,
    accuracy: f64,
    max_evaluations: i32,
    guess: f64,
) -> List {
    let rows = || -> Core<List> {
        let kind = names::parse_price_type(price_type)?;
        let compounding = names::parse_compounding(compounding)?;
        let rows = price
            .iter()
            .zip(&settlement_date)
            .map(|(&p, &s)| {
                bond.z_spread_from_price(
                    &curve.curve,
                    p,
                    kind,
                    compounding,
                    frequency as u32,
                    date(s)?,
                    accuracy,
                    max_evaluations as usize,
                    guess,
                )
            })
            .collect();
        Ok(value_list(rows))
    };
    outcome(rows())
}
#[extendr]
fn compute_bond_value_on_curve(
    bond: ExternalPtr<FixedRateBond>,
    curve: ExternalPtr<OisCurve>,
    evaluation_date: Vec<i32>,
) -> List {
    let n = evaluation_date.len();
    let (mut npv, mut settlement_value) = (Vec::with_capacity(n), Vec::with_capacity(n));
    let (mut dirty_price, mut clean_price) = (Vec::with_capacity(n), Vec::with_capacity(n));
    let mut errors = Vec::with_capacity(n);
    for &d in &evaluation_date {
        match date(d).and_then(|d| bond.value_on_curve(&curve.curve, d)) {
            Ok(v) => {
                npv.push(v.npv);
                settlement_value.push(v.settlement_value);
                dirty_price.push(v.dirty_price);
                clean_price.push(v.clean_price);
                errors.push(String::new());
            }
            Err(e) => {
                npv.push(na_real());
                settlement_value.push(na_real());
                dirty_price.push(na_real());
                clean_price.push(na_real());
                errors.push(e.to_string());
            }
        }
    }
    list!(
        npv = npv,
        settlement_value = settlement_value,
        dirty_price = dirty_price,
        clean_price = clean_price,
        error = errors
    )
}
// ---- Japanese bond calculations --------------------------------------------------------------
/// NA digits stand for no truncation.
fn optional_digits(digits: i32) -> Option<u32> {
    if digits.is_na() {
        None
    } else {
        Some(digits as u32)
    }
}
#[extendr]
fn compute_remaining_years(start: Vec<i32>, end: Vec<i32>) -> List {
    let rows = start
        .iter()
        .zip(&end)
        .map(|(&a, &b)| yen_bond::compute_remaining_years(date(a)?, date(b)?))
        .collect();
    value_list(rows)
}
#[extendr]
fn compute_price_from_simple_rate(
    t: Vec<f64>,
    coupon_rate: Vec<f64>,
    simple_rate: Vec<f64>,
    redemption: Vec<f64>,
    digits: i32,
) -> List {
    let rows = (0..t.len())
        .map(|i| {
            yen_bond::compute_price_from_simple_rate(
                t[i],
                coupon_rate[i],
                simple_rate[i],
                redemption[i],
                optional_digits(digits),
            )
        })
        .collect();
    value_list(rows)
}
#[extendr]
fn compute_simple_rate_from_price(
    t: Vec<f64>,
    coupon_rate: Vec<f64>,
    price: Vec<f64>,
    redemption: Vec<f64>,
    digits: i32,
    max_iterations: i32,
) -> List {
    let rows = (0..t.len())
        .map(|i| {
            yen_bond::compute_simple_rate_from_price(
                t[i],
                coupon_rate[i],
                price[i],
                redemption[i],
                digits as u32,
                max_iterations as usize,
            )
        })
        .collect();
    value_list(rows)
}
fn frequencies(coupon: i32, compound: i32) -> yen_bond::CompoundFrequencies {
    yen_bond::CompoundFrequencies {
        coupon: coupon as u32,
        compound: compound as u32,
    }
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_price_from_compound_yield(
    t: Vec<f64>,
    coupon_rate: Vec<f64>,
    compound_yield: Vec<f64>,
    redemption: Vec<f64>,
    coupon_frequency: i32,
    compound_frequency: i32,
    digits: i32,
) -> List {
    let rows = (0..t.len())
        .map(|i| {
            yen_bond::compute_price_from_compound_yield(
                t[i],
                coupon_rate[i],
                compound_yield[i],
                redemption[i],
                frequencies(coupon_frequency, compound_frequency),
                optional_digits(digits),
            )
        })
        .collect();
    value_list(rows)
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_compound_yield_from_price(
    t: Vec<f64>,
    coupon_rate: Vec<f64>,
    price: Vec<f64>,
    redemption: Vec<f64>,
    coupon_frequency: i32,
    compound_frequency: i32,
    digits: i32,
    max_iterations: i32,
) -> List {
    let rows = (0..t.len())
        .map(|i| {
            yen_bond::compute_compound_yield_from_price(
                t[i],
                coupon_rate[i],
                price[i],
                redemption[i],
                frequencies(coupon_frequency, compound_frequency),
                digits as u32,
                max_iterations as usize,
            )
        })
        .collect();
    value_list(rows)
}
fn risk_list(rows: Vec<Core<yen_bond::YenBondRisk>>) -> List {
    let pick = |f: fn(&yen_bond::YenBondRisk) -> f64| -> Vec<f64> {
        rows.iter()
            .map(|r| r.as_ref().map_or(na_real(), f))
            .collect()
    };
    let errors: Vec<String> = rows
        .iter()
        .map(|r| r.as_ref().err().map_or(String::new(), |e| e.to_string()))
        .collect();
    list!(
        price = pick(|r| r.price),
        accrued_interest = pick(|r| r.accrued_interest),
        dirty_price = pick(|r| r.dirty_price),
        dp_dy_pct = pick(|r| r.dp_dy_pct),
        d2p_dy2_pct = pick(|r| r.d2p_dy2_pct),
        bpv_yen = pick(|r| r.bpv_yen),
        bpv_sen = pick(|r| r.bpv_sen),
        modified_duration = pick(|r| r.modified_duration),
        convexity = pick(|r| r.convexity),
        error = errors
    )
}
#[extendr]
fn compute_risk_from_simple_rate(
    t: Vec<f64>,
    coupon_rate: Vec<f64>,
    simple_rate: Vec<f64>,
    redemption: Vec<f64>,
    accrued_interest: Vec<f64>,
) -> List {
    risk_list(
        (0..t.len())
            .map(|i| {
                yen_bond::compute_risk_from_simple_rate(
                    t[i],
                    coupon_rate[i],
                    simple_rate[i],
                    redemption[i],
                    accrued_interest[i],
                )
            })
            .collect(),
    )
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_risk_from_compound_yield(
    t: Vec<f64>,
    coupon_rate: Vec<f64>,
    compound_yield: Vec<f64>,
    redemption: Vec<f64>,
    accrued_interest: Vec<f64>,
    coupon_frequency: i32,
    compound_frequency: i32,
) -> List {
    risk_list(
        (0..t.len())
            .map(|i| {
                yen_bond::compute_risk_from_compound_yield(
                    t[i],
                    coupon_rate[i],
                    compound_yield[i],
                    redemption[i],
                    frequencies(coupon_frequency, compound_frequency),
                    accrued_interest[i],
                )
            })
            .collect(),
    )
}
// ---- OIS curves ------------------------------------------------------------------------------
/// A tenor of `ON` is an overnight deposit, which has no settlement days, frequency or lag.
#[extendr]
#[allow(clippy::too_many_arguments)]
fn bootstrap_ois_curve(
    evaluation_date: i32,
    reference_date: i32,
    index: &str,
    curve_day_count: &str,
    tenor: Vec<String>,
    rate: Vec<f64>,
    settlement_days: Vec<i32>,
    payment_frequency: Vec<i32>,
    payment_lag: Vec<i32>,
    interpolation: &str,
    accuracy: f64,
) -> List {
    let build = || -> Core<OisCurve> {
        let instruments = (0..tenor.len())
            .map(|i| {
                Ok(if tenor[i] == "ON" {
                    OisCurveInstrument::OvernightDeposit { rate: rate[i] }
                } else {
                    OisCurveInstrument::Ois {
                        tenor: names::parse_period(&tenor[i])?,
                        rate: rate[i],
                        settlement_days: settlement_days[i] as u32,
                        payment_frequency: payment_frequency[i] as u32,
                        payment_lag: payment_lag[i] as u32,
                    }
                })
            })
            .collect::<Core<Vec<_>>>()?;
        rmql::ois::bootstrap_ois_curve(&OisCurveSpec {
            evaluation_date: date(evaluation_date)?,
            reference_date: date(reference_date)?,
            index: names::parse_overnight_index(index)?,
            curve_day_count: names::parse_day_count(curve_day_count)?,
            instruments,
            interpolation: names::parse_ois_interpolation(interpolation)?,
            accuracy,
        })
    };
    outcome(build().map(|curve| list!(value = ExternalPtr::new(curve))))
}
/// The same curve with extrapolation allowed or not; the original value does not change.
#[extendr]
fn with_extrapolation(curve: ExternalPtr<OisCurve>, extrapolate: bool) -> ExternalPtr<OisCurve> {
    let mut changed: OisCurve = (*curve).clone();
    changed.curve = changed.curve.with_extrapolation(extrapolate);
    ExternalPtr::new(changed)
}
#[extendr]
fn compute_discount(curve: ExternalPtr<OisCurve>, date_serial: Vec<i32>) -> List {
    let rows = date_serial
        .iter()
        .map(|&d| curve.curve.discount(date(d)?))
        .collect();
    value_list(rows)
}
#[extendr]
fn compute_zero_rate(
    curve: ExternalPtr<OisCurve>,
    date_serial: Vec<i32>,
    day_count: &str,
    compounding: &str,
    frequency: i32,
) -> List {
    let rows = || -> Core<List> {
        let dc = names::parse_day_count(day_count)?;
        let comp = names::parse_compounding(compounding)?;
        let rows = date_serial
            .iter()
            .map(|&d| {
                Ok(curve
                    .curve
                    .zero_rate(date(d)?, &dc, comp, frequency as u32)?
                    .rate)
            })
            .collect();
        Ok(value_list(rows))
    };
    outcome(rows())
}
#[extendr]
fn compute_forward_rate(
    curve: ExternalPtr<OisCurve>,
    start_date: Vec<i32>,
    end_date: Vec<i32>,
    day_count: &str,
    compounding: &str,
    frequency: i32,
) -> List {
    let rows = || -> Core<List> {
        let dc = names::parse_day_count(day_count)?;
        let comp = names::parse_compounding(compounding)?;
        let rows = start_date
            .iter()
            .zip(&end_date)
            .map(|(&a, &b)| {
                Ok(curve
                    .curve
                    .forward_rate(date(a)?, date(b)?, &dc, comp, frequency as u32)?
                    .rate)
            })
            .collect();
        Ok(value_list(rows))
    };
    outcome(rows())
}
#[extendr]
fn get_quote_repricing(curve: ExternalPtr<OisCurve>) -> List {
    let q = &curve.quote_repricing;
    let serials = |f: fn(&rmql::ois::QuoteRepricing) -> Date| -> Vec<i32> {
        q.iter().map(|r| f(r).serial()).collect()
    };
    list!(
        rate = q.iter().map(|r| r.rate).collect::<Vec<f64>>(),
        start_date = serials(|r| r.start_date),
        maturity_date = serials(|r| r.maturity_date),
        pillar_date = serials(|r| r.pillar_date),
        latest_relevant_date = serials(|r| r.latest_relevant_date),
        used_in_bootstrap = q.iter().map(|r| r.used_in_bootstrap).collect::<Vec<bool>>(),
        implied_rate = q
            .iter()
            .map(|r| r.implied_rate.unwrap_or_else(na_real))
            .collect::<Vec<f64>>()
    )
}
#[extendr]
fn get_discount_nodes(curve: ExternalPtr<OisCurve>) -> List {
    match curve.curve.discount_nodes() {
        Some((dates, values)) => list!(
            value = list!(date = dates.iter().map(|d| d.serial()).collect::<Vec<i32>>(), discount = values.to_vec())
        ),
        None => failure(rmql::Error::InvalidInput { reason: "this curve is not given by discount factors".into() }),
    }
}
// ---- curves given directly -----------------------------------------------------------------------
fn given_curve(build: impl FnOnce() -> Core<YieldCurve>, index: &str) -> List {
    let run = || -> Core<OisCurve> { Ok(OisCurve::given(build()?, names::parse_overnight_index(index)?)) };
    outcome(run().map(|curve| list!(value = ExternalPtr::new(curve))))
}
#[extendr]
fn create_flat_curve(reference_date: i32, rate: f64, day_count: &str, compounding: &str, frequency: i32, index: &str) -> List {
    given_curve(
        || {
            let rate = InterestRate::new(rate, names::parse_day_count(day_count)?, names::parse_compounding(compounding)?, frequency.max(0) as u32)?;
            Ok(YieldCurve::flat(date(reference_date)?, rate))
        },
        index,
    )
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn create_zero_curve(dates: Vec<i32>, rates: Vec<f64>, day_count: &str, compounding: &str, frequency: i32, index: &str) -> List {
    given_curve(
        || {
            let dates = dates.iter().map(|&d| date(d)).collect::<Core<Vec<_>>>()?;
            YieldCurve::zero(dates, rates, names::parse_day_count(day_count)?, names::parse_compounding(compounding)?, frequency.max(0) as u32)
        },
        index,
    )
}
#[extendr]
fn create_discount_curve(dates: Vec<i32>, discounts: Vec<f64>, day_count: &str, interpolation: &str, index: &str) -> List {
    given_curve(
        || {
            let dates = dates.iter().map(|&d| date(d)).collect::<Core<Vec<_>>>()?;
            let interpolation = match interpolation {
                "log_linear" => LogDiscountInterpolation::LogLinear,
                "monotonic_log_cubic" => LogDiscountInterpolation::MonotonicLogCubic,
                other => {
                    return Err(rmql::Error::InvalidInput { reason: format!("interpolation must be log_linear or monotonic_log_cubic, not {other}") })
                }
            };
            YieldCurve::interpolated_discounts(dates, discounts, names::parse_day_count(day_count)?, interpolation)
        },
        index,
    )
}
#[extendr]
fn create_zero_spreaded_curve(curve: ExternalPtr<OisCurve>, spread: Vec<f64>, compounding: &str, frequency: i32, dates: Vec<i32>) -> List {
    let run = || -> Core<OisCurve> {
        let (compounding, frequency) = (names::parse_compounding(compounding)?, frequency.max(0) as u32);
        let spreaded = if dates.is_empty() {
            match spread.as_slice() {
                [s] => YieldCurve::zero_spreaded(curve.curve.clone(), *s, compounding, frequency)?,
                _ => return Err(rmql::Error::InvalidInput { reason: "a spread without dates must be one number".into() }),
            }
        } else {
            let dates = dates.iter().map(|&d| date(d)).collect::<Core<Vec<_>>>()?;
            YieldCurve::piecewise_zero_spreaded(curve.curve.clone(), dates, spread.clone(), compounding, frequency)?
        };
        Ok(OisCurve::given(spreaded, curve.spec.index.clone()))
    };
    outcome(run().map(|c| list!(value = ExternalPtr::new(c))))
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn bootstrap_bond_curve(
    evaluation_date: i32,
    reference_date: i32,
    bonds: List,
    prices: Vec<f64>,
    price_type: &str,
    day_count: &str,
    interpolation: &str,
    accuracy: f64,
    index: &str,
) -> List {
    let run = || -> Core<BondCurve> {
        if bonds.len() != prices.len() {
            return Err(rmql::Error::InvalidInput { reason: "one price per bond is needed".into() });
        }
        let price_type = names::parse_price_type(price_type)?;
        let quotes = bonds
            .values()
            .zip(&prices)
            .map(|(b, &price)| {
                let bond = ExternalPtr::<FixedRateBond>::try_from(b)
                    .map_err(|_| rmql::Error::InvalidInput { reason: "every bond must come from create_fixed_rate_bond()".into() })?;
                Ok(BondCurveQuote { bond: (*bond).clone(), price, price_type })
            })
            .collect::<Core<Vec<_>>>()?;
        let interpolation = match interpolation {
            "linear_zero" => BondCurveInterpolation::LinearZero,
            "log_linear_discount" => BondCurveInterpolation::LogLinearDiscount,
            other => {
                return Err(rmql::Error::InvalidInput {
                    reason: format!("interpolation must be linear_zero or log_linear_discount, not {other}"),
                })
            }
        };
        bond_curve::bootstrap_bond_curve(&BondCurveSpec {
            evaluation_date: date(evaluation_date)?,
            reference_date: date(reference_date)?,
            day_count: names::parse_day_count(day_count)?,
            interpolation,
            accuracy,
            quotes,
        })
    };
    let index = names::parse_overnight_index(index);
    outcome(run().and_then(|c| {
        let curve = OisCurve::given(c.curve, index?);
        Ok(list!(
            value = ExternalPtr::new(curve),
            pillar_date = c.quote_repricing.iter().map(|r| r.pillar_date.serial() as f64).collect::<Vec<f64>>(),
            implied_price = c.quote_repricing.iter().map(|r| r.implied_price).collect::<Vec<f64>>()
        ))
    }))
}
// ---- sensitivities ---------------------------------------------------------------------------
#[extendr]
fn compute_yield_sensitivity(
    bond: ExternalPtr<FixedRateBond>,
    rate: Vec<f64>,
    day_count: &str,
    compounding: &str,
    frequency: i32,
    settlement_date: Vec<i32>,
) -> List {
    let rows = || -> Core<List> {
        let convention = yield_convention(day_count, compounding, frequency)?;
        let n = rate.len();
        let (mut price, mut first, mut second) =
            (Vec::with_capacity(n), Vec::with_capacity(n), Vec::with_capacity(n));
        let mut errors = Vec::with_capacity(n);
        for (&r, &s) in rate.iter().zip(&settlement_date) {
            let row = convention
                .rate(r)
                .and_then(|y| risk::compute_yield_sensitivity(&bond, &y, date(s)?));
            match row {
                Ok(v) => {
                    price.push(v.dirty_price);
                    first.push(v.d_price_d_yield);
                    second.push(v.d2_price_d_yield2);
                    errors.push(String::new());
                }
                Err(e) => {
                    price.push(na_real());
                    first.push(na_real());
                    second.push(na_real());
                    errors.push(e.to_string());
                }
            }
        }
        Ok(list!(
            dirty_price = price,
            d_price_d_yield = first,
            d2_price_d_yield2 = second,
            error = errors
        ))
    };
    outcome(rows())
}
#[extendr]
fn compute_curve_node_sensitivity(
    bond: ExternalPtr<FixedRateBond>,
    curve: ExternalPtr<OisCurve>,
    evaluation_date: i32,
) -> List {
    let rows = || -> Core<List> {
        let (value, rows) = risk::compute_curve_sensitivity(&bond, &curve.curve, date(evaluation_date)?)?;
        let (mut dates, mut times) = (Vec::new(), Vec::new());
        let (mut d_npv, mut d_price) = (Vec::new(), Vec::new());
        for row in rows {
            if let CurveInput::LogDiscount { date, time } = row.input {
                dates.push(date.serial() as f64);
                times.push(time);
                d_npv.push(row.d_npv);
                d_price.push(row.d_dirty_price);
            }
        }
        Ok(list!(
            npv = value.npv,
            dirty_price = value.dirty_price,
            date = dates,
            time = times,
            d_npv = d_npv,
            d_dirty_price = d_price
        ))
    };
    outcome(rows())
}
#[extendr]
fn compute_quote_sensitivity(
    bond: ExternalPtr<FixedRateBond>,
    curve: ExternalPtr<OisCurve>,
    evaluation_date: i32,
) -> List {
    let rows = || -> Core<List> {
        let (value, rows) = risk::compute_quote_sensitivity(&bond, &curve, date(evaluation_date)?)?;
        Ok(list!(
            npv = value.npv,
            dirty_price = value.dirty_price,
            instrument = rows.iter().map(|r| r.instrument as i32 + 1).collect::<Vec<i32>>(),
            pillar_date = rows.iter().map(|r| r.pillar_date.serial() as f64).collect::<Vec<f64>>(),
            rate = rows.iter().map(|r| r.quote).collect::<Vec<f64>>(),
            d_npv = rows.iter().map(|r| r.d_npv).collect::<Vec<f64>>(),
            d_dirty_price = rows.iter().map(|r| r.d_dirty_price).collect::<Vec<f64>>()
        ))
    };
    outcome(rows())
}
// ---- asset swaps and futures basis ----------------------------------------------------------
#[extendr]
fn compute_ois_asset_swap(
    bond: ExternalPtr<FixedRateBond>,
    curve: ExternalPtr<OisCurve>,
    clean_price: Vec<f64>,
    spread: Vec<f64>,
    payment_frequency: i32,
    payment_lag: i32,
    evaluation_date: i32,
) -> List {
    let (columns, error) = table(clean_price.len(), |i| {
        let v = asset_swap::compute_ois_asset_swap(
            &bond,
            &curve.curve,
            &curve.spec.index,
            &OisAssetSwapTerms {
                clean_price: clean_price[i],
                payment_frequency: payment_frequency as u32,
                payment_lag: payment_lag.max(0) as u32,
                spread: spread[i],
            },
            date(evaluation_date)?,
        )?;
        Ok([
            v.accrued,
            v.dirty_price,
            v.fair_spread,
            v.spread_annuity,
            v.npv,
            v.bond_leg_pv,
            v.overnight_leg_pv,
            v.principal_pv,
            v.upfront_pv,
            v.fair_clean_price,
            v.effective_date.serial() as f64,
            v.maturity_date.serial() as f64,
        ])
    });
    list!(
        accrued = columns[0].clone(),
        dirty_price = columns[1].clone(),
        fair_spread = columns[2].clone(),
        spread_annuity = columns[3].clone(),
        npv = columns[4].clone(),
        bond_leg_pv = columns[5].clone(),
        overnight_leg_pv = columns[6].clone(),
        principal_pv = columns[7].clone(),
        upfront_pv = columns[8].clone(),
        fair_clean_price = columns[9].clone(),
        effective_date = columns[10].clone(),
        maturity_date = columns[11].clone(),
        error = error
    )
}
#[extendr]
fn compute_asset_swap_quote_sensitivity(
    bond: ExternalPtr<FixedRateBond>,
    curve: ExternalPtr<OisCurve>,
    clean_price: f64,
    payment_frequency: i32,
    payment_lag: i32,
    evaluation_date: i32,
) -> List {
    let run = || -> Core<List> {
        let rows = asset_swap::compute_asset_swap_quote_sensitivity(
            &bond,
            &curve,
            &OisAssetSwapTerms {
                clean_price,
                payment_frequency: payment_frequency as u32,
                payment_lag: payment_lag.max(0) as u32,
                spread: 0.0,
            },
            date(evaluation_date)?,
        )?;
        Ok(list!(
            instrument = rows.iter().map(|r| r.instrument as i32 + 1).collect::<Vec<i32>>(),
            pillar_date = rows.iter().map(|r| r.pillar_date.serial() as f64).collect::<Vec<f64>>(),
            rate = rows.iter().map(|r| r.quote).collect::<Vec<f64>>(),
            d_fair_spread = rows.iter().map(|r| r.d_fair_spread).collect::<Vec<f64>>()
        ))
    };
    outcome(run())
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_yen_asset_swap(
    bond: ExternalPtr<FixedRateBond>,
    foreign_curve: ExternalPtr<OisCurve>,
    yen_curve: ExternalPtr<OisCurve>,
    clean_price: Vec<f64>,
    fx_spot: Vec<f64>,
    basis: Vec<f64>,
    spread: Vec<f64>,
    foreign_payment_frequency: i32,
    yen_payment_frequency: i32,
    foreign_payment_lag: i32,
    yen_payment_lag: i32,
    evaluation_date: i32,
) -> List {
    let (columns, error) = table(clean_price.len(), |i| {
        let terms = |frequency: i32, lag: i32| OisAssetSwapTerms {
            clean_price: clean_price[i],
            payment_frequency: frequency as u32,
            payment_lag: lag.max(0) as u32,
            spread: 0.0,
        };
        let v = asset_swap::compute_yen_asset_swap(
            &bond,
            &foreign_curve.curve,
            &foreign_curve.spec.index,
            &terms(foreign_payment_frequency, foreign_payment_lag),
            &yen_curve.curve,
            &yen_curve.spec.index,
            &terms(yen_payment_frequency, yen_payment_lag),
            &YenBasisTerms { fx_spot: fx_spot[i], basis: basis[i], spread: spread[i] },
            date(evaluation_date)?,
        )?;
        Ok([
            v.native_fair_spread,
            v.yen_fair_spread,
            v.simple_sum,
            v.npv,
            v.hedged_bond_pv,
            v.yen_base_leg_pv,
            v.upfront_pv,
            v.spread_annuity,
            v.calibrated_discount_spread,
        ])
    });
    list!(
        native_fair_spread = columns[0].clone(),
        yen_fair_spread = columns[1].clone(),
        simple_sum = columns[2].clone(),
        npv = columns[3].clone(),
        hedged_bond_pv = columns[4].clone(),
        yen_base_leg_pv = columns[5].clone(),
        upfront_pv = columns[6].clone(),
        spread_annuity = columns[7].clone(),
        calibrated_discount_spread = columns[8].clone(),
        error = error
    )
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_yen_asset_swap_on_basis_curve(
    bond: ExternalPtr<FixedRateBond>,
    foreign_curve: ExternalPtr<OisCurve>,
    yen_curve: ExternalPtr<OisCurve>,
    basis_curve: ExternalPtr<OisCurve>,
    clean_price: Vec<f64>,
    fx_spot: Vec<f64>,
    spread: Vec<f64>,
    foreign_payment_frequency: i32,
    yen_payment_frequency: i32,
    foreign_payment_lag: i32,
    yen_payment_lag: i32,
    evaluation_date: i32,
) -> List {
    let (columns, error) = table(clean_price.len(), |i| {
        let terms = |frequency: i32, lag: i32| OisAssetSwapTerms {
            clean_price: clean_price[i],
            payment_frequency: frequency as u32,
            payment_lag: lag.max(0) as u32,
            spread: 0.0,
        };
        let v = asset_swap::compute_yen_asset_swap_on_basis_curve(
            &bond,
            &foreign_curve.curve,
            &foreign_curve.spec.index,
            &terms(foreign_payment_frequency, foreign_payment_lag),
            &yen_curve.curve,
            &yen_curve.spec.index,
            &terms(yen_payment_frequency, yen_payment_lag),
            &basis_curve.curve,
            fx_spot[i],
            spread[i],
            date(evaluation_date)?,
        )?;
        Ok([v.native_fair_spread, v.yen_fair_spread, v.npv, v.hedged_bond_pv, v.yen_base_leg_pv, v.upfront_pv, v.spread_annuity])
    });
    list!(
        native_fair_spread = columns[0].clone(),
        yen_fair_spread = columns[1].clone(),
        npv = columns[2].clone(),
        hedged_bond_pv = columns[3].clone(),
        yen_base_leg_pv = columns[4].clone(),
        upfront_pv = columns[5].clone(),
        spread_annuity = columns[6].clone(),
        error = error
    )
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn bootstrap_xccy_curve(
    evaluation_date: i32,
    base_curve: ExternalPtr<OisCurve>,
    quote_curve: ExternalPtr<OisCurve>,
    collateral_curve: ExternalPtr<OisCurve>,
    base_is_collateral: bool,
    fx_spot: f64,
    kind: Vec<String>,
    tenor: Vec<String>,
    quote: Vec<f64>,
    fixing_days: Vec<i32>,
    payment_frequency: Vec<i32>,
    basis_on_base_leg: Vec<i32>,
    resetting: Vec<String>,
    calendar: &str,
    convention: &str,
    end_of_month: bool,
    day_count: &str,
    accuracy: f64,
) -> List {
    let build = || -> Core<XccyCurve> {
        let today = date(evaluation_date)?;
        let instruments = (0..kind.len())
            .map(|i| {
                let tenor = names::parse_period(&tenor[i])?;
                let fixing_days = fixing_days[i].max(0) as u32;
                Ok(match kind[i].as_str() {
                    "fx_swap" => XccyInstrument::FxSwap { tenor, fixing_days, forward_points: quote[i] },
                    "basis_swap" => XccyInstrument::BasisSwap {
                        tenor,
                        fixing_days,
                        payment_frequency: payment_frequency[i].max(0) as u32,
                        basis: quote[i],
                        basis_on_base_leg: basis_on_base_leg[i] != 0,
                        resetting: match resetting[i].as_str() {
                            "none" => ResettingLeg::None,
                            "base" => ResettingLeg::Base,
                            "quote" => ResettingLeg::Quote,
                            other => {
                                return Err(rmql::Error::InvalidInput {
                                    reason: format!("resetting must be none, base or quote, not {other}"),
                                })
                            }
                        },
                    },
                    other => return Err(rmql::Error::InvalidInput { reason: format!("type must be fx_swap or basis_swap, not {other}") }),
                })
            })
            .collect::<Core<Vec<_>>>()?;
        let horizon = Date::from_serial(today.serial() as i64 + 366 * 61)?;
        let calendar = if calendar.is_empty() {
            base_curve.spec.index.calendar.joined_with(&quote_curve.spec.index.calendar, today, horizon)?
        } else {
            HolidayCalendar::from(names::parse_calendar(calendar)?)
        };
        bootstrap_xccy_curve_core(&XccyCurveSpec {
            evaluation_date: today,
            day_count: names::parse_day_count(day_count)?,
            base: XccyLeg { index: base_curve.spec.index.clone(), forecast: base_curve.curve.clone() },
            quote: XccyLeg { index: quote_curve.spec.index.clone(), forecast: quote_curve.curve.clone() },
            base_is_collateral,
            collateral_curve: collateral_curve.curve.clone(),
            fx_spot,
            calendar,
            convention: names::parse_business_day_convention(convention)?,
            end_of_month,
            accuracy,
            instruments,
        })
    };
    let index = if base_is_collateral { quote_curve.spec.index.clone() } else { base_curve.spec.index.clone() };
    outcome(build().map(|c| {
        let curve = OisCurve::given(c.curve, index);
        list!(
            value = ExternalPtr::new(curve),
            pillar_date = c.quote_repricing.iter().map(|r| r.pillar_date.serial() as f64).collect::<Vec<f64>>(),
            implied_quote = c.quote_repricing.iter().map(|r| r.implied_quote).collect::<Vec<f64>>()
        )
    }))
}
#[extendr]
fn create_ctd_curve(reference_date: i32, end_date: i32, day_count: &str, names_of: Vec<String>, curves: List) -> List {
    let build = || -> Core<rmql::ctd::CtdCurve> {
        if names_of.len() != curves.len() {
            return Err(rmql::Error::InvalidInput { reason: "one name per curve is needed".into() });
        }
        let options = curves
            .values()
            .zip(&names_of)
            .map(|(c, name)| {
                let curve = ExternalPtr::<OisCurve>::try_from(c)
                    .map_err(|_| rmql::Error::InvalidInput { reason: "every curve must be a rmql_ois_curve".into() })?;
                Ok(rmql::ctd::CollateralOption { name: name.clone(), curve: curve.curve.clone() })
            })
            .collect::<Core<Vec<_>>>()?;
        rmql::ctd::create_ctd_curve(date(reference_date)?, date(end_date)?, &names::parse_day_count(day_count)?, &options)
    };
    let index = curves
        .values()
        .next()
        .and_then(|c| ExternalPtr::<OisCurve>::try_from(c).ok())
        .map(|c| c.spec.index.clone());
    outcome(build().and_then(|c| {
        let index = index.ok_or_else(|| rmql::Error::InvalidInput { reason: "no curves given".into() })?;
        Ok(list!(
            value = ExternalPtr::new(OisCurve::given(c.curve, index)),
            start = c.choices.iter().map(|x| x.start.serial() as f64).collect::<Vec<f64>>(),
            end = c.choices.iter().map(|x| x.end.serial() as f64).collect::<Vec<f64>>(),
            option = c.choices.iter().map(|x| x.option as i32 + 1).collect::<Vec<i32>>(),
            advantage = c.choices.iter().map(|x| x.advantage).collect::<Vec<f64>>()
        ))
    }))
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_ctd_time_value(
    reference_date: i32,
    dates: Vec<i32>,
    day_count: &str,
    names_of: Vec<String>,
    curves: List,
    volatility: Vec<f64>,
    mean_reversion: Vec<f64>,
    correlation: Vec<f64>,
    paths: i32,
    seed: f64,
) -> List {
    let run = || -> Core<List> {
        if names_of.len() != curves.len() {
            return Err(rmql::Error::InvalidInput { reason: "one name per curve is needed".into() });
        }
        if volatility.len() != mean_reversion.len() {
            return Err(rmql::Error::InvalidInput { reason: "give one mean reversion per volatility".into() });
        }
        let options = curves
            .values()
            .zip(&names_of)
            .map(|(c, name)| {
                let curve = ExternalPtr::<OisCurve>::try_from(c)
                    .map_err(|_| rmql::Error::InvalidInput { reason: "every curve must be a rmql_ois_curve".into() })?;
                Ok(rmql::ctd::CollateralOption { name: name.clone(), curve: curve.curve.clone() })
            })
            .collect::<Core<Vec<_>>>()?;
        let spreads: Vec<_> = volatility
            .iter()
            .zip(&mean_reversion)
            .map(|(&v, &k)| rmql::ctd::SpreadDynamics { volatility: v, mean_reversion: k })
            .collect();
        let days = dates.iter().map(|&d| date(d)).collect::<Core<Vec<_>>>()?;
        let r = rmql::ctd::compute_ctd_time_value(
            date(reference_date)?,
            &days,
            &names::parse_day_count(day_count)?,
            &options,
            &spreads,
            &correlation,
            paths.max(0) as usize,
            seed as u64,
        )?;
        Ok(list!(
            intrinsic = r.intrinsic,
            value = r.value,
            standard_error = r.standard_error,
            first_order = r.first_order,
            log_standard_error = r.log_standard_error,
            first_order_formula = r.first_order_formula.unwrap_or_else(|| vec![f64::NAN; days.len()])
        ))
    };
    outcome(run())
}
#[extendr]
fn compute_future_basis(
    bond: ExternalPtr<FixedRateBond>,
    clean_price: f64,
    futures_price: f64,
    conversion_factor: f64,
    funding_rate: f64,
    valuation_date: i32,
    delivery_date: i32,
) -> List {
    let run = || -> Core<List> {
        let v = asset_swap::compute_future_basis(
            &bond,
            &FutureBasisTerms {
                clean_price,
                futures_price,
                conversion_factor,
                funding_rate,
                valuation_date: date(valuation_date)?,
                delivery_date: date(delivery_date)?,
            },
        )?;
        Ok(list!(
            accrued_start = v.accrued_start,
            accrued_end = v.accrued_end,
            coupon_income = v.coupon_income,
            futures_invoice = v.futures_invoice,
            gross_basis = v.gross_basis,
            funding_cost = v.funding_cost,
            carry = v.carry,
            net_basis = v.net_basis,
            implied_repo = v.implied_repo
        ))
    };
    outcome(run())
}
// ---- Hull-White and SABR ---------------------------------------------------------------------
/// `spacing` above 0 selects the trapezoid rule; otherwise `nodes` of Gauss-Hermite.
fn grid_settings(points: i32, limit: f64, nodes: i32, spacing: f64) -> GridSettings {
    GridSettings {
        points: points.max(0) as usize,
        limit,
        quadrature: if spacing > 0.0 {
            Quadrature::Trapezoid(spacing)
        } else {
            Quadrature::GaussHermite(nodes.max(0) as usize)
        },
    }
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_hull_white_bond_option_value(
    option_type: Vec<String>,
    strike: Vec<f64>,
    maturity: Vec<f64>,
    bond_maturity: Vec<f64>,
    mean_reversion: f64,
    volatility: f64,
    curve: ExternalPtr<OisCurve>,
) -> List {
    let model = HullWhite { mean_reversion, volatility, curve: &curve.curve };
    let rows = (0..strike.len())
        .map(|i| {
            model.discount_bond_option(
                names::parse_option_type(&option_type[i])?,
                strike[i],
                maturity[i],
                maturity[i],
                bond_maturity[i],
            )
        })
        .collect();
    value_list(rows)
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_hull_white_swaption_value(
    payer: bool,
    maturity: f64,
    payment_times: Vec<f64>,
    coupons: Vec<f64>,
    nominal: f64,
    mean_reversion: f64,
    volatility: f64,
    curve: ExternalPtr<OisCurve>,
) -> List {
    let flows = SwaptionFlows { payer, maturity, value_time: maturity, payment_times, coupons, nominal };
    outcome(
        hull_white::compute_jamshidian_swaption_sensitivity(mean_reversion, volatility, &curve.curve, &flows).map(|s| {
            list!(value = s.value, d_mean_reversion = s.d_mean_reversion, d_volatility = s.d_volatility)
        }),
    )
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_hull_white_bermudan_swaption_value(
    payer: bool,
    maturity: f64,
    payment_times: Vec<f64>,
    coupons: Vec<f64>,
    nominal: f64,
    exercise_times: Vec<f64>,
    mean_reversion: f64,
    volatility: f64,
    curve: ExternalPtr<OisCurve>,
    points: i32,
    limit: f64,
    nodes: i32,
    spacing: f64,
) -> List {
    let flows = SwaptionFlows { payer, maturity, value_time: maturity, payment_times, coupons, nominal };
    let settings = grid_settings(points, limit, nodes, spacing);
    outcome(
        hull_white::compute_bermudan_swaption(&flows, &exercise_times, mean_reversion, volatility, &curve.curve, &settings)
            .map(|value| list!(value = value)),
    )
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_hull_white_callable_bond_value(
    time: Vec<f64>,
    coupon: Vec<f64>,
    principal: Vec<f64>,
    call_price: Vec<f64>,
    mean_reversion: f64,
    volatility: f64,
    curve: ExternalPtr<OisCurve>,
    points: i32,
    limit: f64,
    nodes: i32,
    spacing: f64,
) -> List {
    let flows: Vec<CallableFlow> = (0..time.len())
        .map(|i| CallableFlow {
            time: time[i],
            coupon: coupon[i],
            principal: principal[i],
            // R has turned NA into a value of NaN here, which means no call on this date
            call_price: if call_price[i].is_nan() { None } else { Some(call_price[i]) },
        })
        .collect();
    let settings = grid_settings(points, limit, nodes, spacing);
    outcome(
        hull_white::compute_callable_bond(&flows, mean_reversion, volatility, &curve.curve, &settings).map(|v| {
            list!(bullet = v.bullet, callable = v.callable, issuer_call_value = v.issuer_call_value)
        }),
    )
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_hull_white_callable_bond_decisions(
    time: Vec<f64>,
    coupon: Vec<f64>,
    principal: Vec<f64>,
    call_price: Vec<f64>,
    mean_reversion: f64,
    volatility: f64,
    curve: ExternalPtr<OisCurve>,
    points: i32,
    limit: f64,
    nodes: i32,
    spacing: f64,
) -> List {
    let flows: Vec<CallableFlow> = (0..time.len())
        .map(|i| CallableFlow {
            time: time[i],
            coupon: coupon[i],
            principal: principal[i],
            // R has turned NA into a value of NaN here, which means no call on this date
            call_price: if call_price[i].is_nan() { None } else { Some(call_price[i]) },
        })
        .collect();
    let settings = grid_settings(points, limit, nodes, spacing);
    outcome(
        hull_white::compute_callable_bond_decisions(&flows, mean_reversion, volatility, &curve.curve, &settings).map(|r| {
            // one row per call date and state, in increasing time and state
            let mut payment_time = Vec::new();
            let mut state = Vec::new();
            let mut short_rate = Vec::new();
            let mut continuation = Vec::new();
            let mut price = Vec::new();
            let mut exercise = Vec::new();
            for d in &r.decisions {
                for k in 0..d.states.len() {
                    payment_time.push(d.time);
                    state.push(d.states[k]);
                    short_rate.push(d.short_rates[k]);
                    continuation.push(d.continuation[k]);
                    price.push(d.call_price);
                    exercise.push(d.exercise[k]);
                }
            }
            list!(
                bullet = r.value.bullet,
                callable = r.value.callable,
                issuer_call_value = r.value.issuer_call_value,
                payment_time = payment_time,
                state = state,
                short_rate = short_rate,
                continuation_ex_coupon = continuation,
                call_price = price,
                exercise_now = exercise
            )
        }),
    )
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_sabr_volatility(
    kind: &str,
    strike: Vec<f64>,
    forward: Vec<f64>,
    expiry: Vec<f64>,
    alpha: Vec<f64>,
    beta: Vec<f64>,
    nu: Vec<f64>,
    rho: Vec<f64>,
) -> List {
    let rows = || -> Core<List> {
        let kind = names::parse_sabr_volatility_type(kind)?;
        let rows = (0..strike.len())
            .map(|i| {
                sabr::compute_sabr_volatility(
                    kind,
                    strike[i],
                    forward[i],
                    expiry[i],
                    &SabrParameters { alpha: alpha[i], beta: beta[i], nu: nu[i], rho: rho[i] },
                )
            })
            .collect();
        Ok(value_list(rows))
    };
    outcome(rows())
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn calibrate_hull_white(
    option_type: Vec<String>,
    strike: Vec<f64>,
    option_maturity: Vec<f64>,
    bond_maturity: Vec<f64>,
    option_price: Vec<f64>,
    option_weight: Vec<f64>,
    payer: Vec<i32>,
    swaption_maturity: Vec<f64>,
    flow_counts: Vec<i32>,
    payment_times: Vec<f64>,
    coupons: Vec<f64>,
    nominal: Vec<f64>,
    swaption_price: Vec<f64>,
    swaption_weight: Vec<f64>,
    curve: ExternalPtr<OisCurve>,
    initial_mean_reversion: f64,
    initial_volatility: f64,
    fix_mean_reversion: bool,
    max_iterations: i32,
) -> List {
    let run = || -> Core<List> {
        let mut quotes = Vec::with_capacity(strike.len() + payer.len());
        for i in 0..strike.len() {
            quotes.push(CalibrationQuote {
                instrument: CalibrationInstrument::BondOption {
                    kind: names::parse_option_type(&option_type[i])?,
                    strike: strike[i],
                    maturity: option_maturity[i],
                    bond_maturity: bond_maturity[i],
                },
                price: option_price[i],
                weight: option_weight[i],
            });
        }
        let mut start = 0;
        for i in 0..payer.len() {
            let end = start + flow_counts[i] as usize;
            quotes.push(CalibrationQuote {
                instrument: CalibrationInstrument::Swaption(SwaptionFlows {
                    payer: payer[i] != 0,
                    maturity: swaption_maturity[i],
                    value_time: swaption_maturity[i],
                    payment_times: payment_times[start..end].to_vec(),
                    coupons: coupons[start..end].to_vec(),
                    nominal: nominal[i],
                }),
                price: swaption_price[i],
                weight: swaption_weight[i],
            });
            start = end;
        }
        let settings = CalibrationSettings {
            initial_mean_reversion,
            initial_volatility,
            fix_mean_reversion,
            max_iterations: max_iterations.max(0) as usize,
        };
        let c = hull_white::calibrate_hull_white(&quotes, &curve.curve, &settings)?;
        Ok(list!(
            mean_reversion = c.mean_reversion,
            volatility = c.volatility,
            objective = c.objective,
            root_mean_square_error = c.root_mean_square_error,
            at_lower_limit = c.at_lower_limit,
            iterations = c.iterations as i32,
            stop_reason = c.stop.name(),
            model_prices = c.model_prices
        ))
    };
    outcome(run())
}
#[extendr]
fn calibrate_sabr(kind: &str, strike: Vec<f64>, volatility: Vec<f64>, forward: f64, expiry: f64, beta: f64) -> List {
    let run = || -> Core<List> {
        let c = sabr::calibrate_sabr(names::parse_sabr_volatility_type(kind)?, &strike, &volatility, forward, expiry, beta)?;
        Ok(list!(
            alpha = c.parameters.alpha,
            beta = c.parameters.beta,
            nu = c.parameters.nu,
            rho = c.parameters.rho,
            root_mean_square_error = c.root_mean_square_error,
            iterations = c.iterations as i32
        ))
    };
    outcome(run())
}
// ---- credit default swaps ----------------------------------------------------------------------
fn cds_value_list(v: CdsValue) -> List {
    list!(
        npv = v.npv,
        coupon_leg_npv = v.coupon_leg_npv,
        default_leg_npv = v.default_leg_npv,
        upfront_npv = v.upfront_npv,
        accrual_rebate_npv = v.accrual_rebate_npv,
        fair_spread = v.fair_spread,
        fair_upfront = v.fair_upfront.unwrap_or_else(na_real)
    )
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn create_credit_default_swap(
    side: &str,
    notional: f64,
    running_spread: f64,
    effective_date: i32,
    termination_date: i32,
    tenor: &str,
    calendar: &str,
    convention: &str,
    termination_convention: &str,
    rule: &str,
    payment_convention: &str,
    day_count: &str,
    upfront: f64,
    rebates_accrual: bool,
    trade_date: i32,
    protection_start: i32,
    cash_settlement_days: i32,
    last_period_day_count: &str,
) -> List {
    let build = || -> Core<Cds> {
        Cds::new(CdsSpec {
            side: names::parse_protection_side(side)?,
            notional,
            running_spread,
            schedule: ScheduleSpec {
                effective_date: date(effective_date)?,
                termination_date: date(termination_date)?,
                tenor: names::parse_period(tenor)?,
                calendar: HolidayCalendar::from(names::parse_calendar(calendar)?),
                convention: names::parse_business_day_convention(convention)?,
                termination_convention: names::parse_business_day_convention(termination_convention)?,
                rule: names::parse_date_generation_rule(rule)?,
                end_of_month: false,
                first_date: None,
                next_to_last_date: None,
            },
            payment_convention: names::parse_business_day_convention(payment_convention)?,
            day_count: names::parse_day_count(day_count)?,
            last_period_day_count: if last_period_day_count.is_empty() {
                None
            } else {
                Some(names::parse_day_count(last_period_day_count)?)
            },
            upfront: Some(upfront),
            protection_start: optional_date(protection_start)?,
            trade_date: optional_date(trade_date)?,
            cash_settlement_days,
            rebates_accrual,
        })
    };
    outcome(build().map(|c| list!(value = ExternalPtr::new(c))))
}
#[extendr]
fn create_hazard_curve(reference_date: i32, day_count: &str, dates: Vec<i32>, hazards: Vec<f64>) -> List {
    let build = || -> Core<HazardCurve> {
        let reference = date(reference_date)?;
        let dates = dates.iter().map(|&d| date(d)).collect::<Core<Vec<Date>>>()?;
        HazardCurve::new(reference, names::parse_day_count(day_count)?, dates, hazards.clone())
    };
    outcome(build().map(|c| list!(value = ExternalPtr::new(c))))
}
#[extendr]
fn create_survival_probability_curve(reference_date: i32, day_count: &str, dates: Vec<i32>, probabilities: Vec<f64>) -> List {
    let build = || -> Core<HazardCurve> {
        let reference = date(reference_date)?;
        let dates = dates.iter().map(|&d| date(d)).collect::<Core<Vec<Date>>>()?;
        HazardCurve::survival_probabilities(reference, names::parse_day_count(day_count)?, dates, probabilities.clone())
    };
    outcome(build().map(|c| list!(value = ExternalPtr::new(c))))
}
#[extendr]
fn compute_survival_probability(curve: ExternalPtr<HazardCurve>, date_serial: Vec<i32>) -> List {
    let rows = date_serial.iter().map(|&d| curve.survival(date(d)?)).collect();
    value_list(rows)
}
#[extendr]
fn compute_hazard_rate(curve: ExternalPtr<HazardCurve>, date_serial: Vec<i32>) -> List {
    let rows = date_serial.iter().map(|&d| curve.hazard_rate(date(d)?)).collect();
    value_list(rows)
}
#[extendr]
fn compute_cds_value(
    cds: ExternalPtr<Cds>,
    hazard: ExternalPtr<HazardCurve>,
    recovery: f64,
    curve: ExternalPtr<OisCurve>,
    evaluation_date: i32,
    engine: &str,
) -> List {
    let run = || -> Core<List> {
        let v = cds::compute_cds_value(names::parse_cds_engine(engine)?, &cds, &hazard, recovery, &curve.curve, date(evaluation_date)?)?;
        Ok(cds_value_list(v))
    };
    outcome(run())
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn bootstrap_hazard_curve(
    evaluation_date: i32,
    maturity: Vec<i32>,
    spread: Vec<f64>,
    recovery: f64,
    curve: ExternalPtr<OisCurve>,
    engine: &str,
    settlement_days: i32,
    calendar: &str,
    tenor: &str,
    payment_convention: &str,
    rule: &str,
    day_count: &str,
    curve_day_count: &str,
    accuracy: f64,
    quote_type: &str,
    running_spread: f64,
    upfront_settlement_days: i32,
) -> List {
    let build = || -> Core<CdsCurve> {
        let quote_type = match quote_type {
            "spread" => CdsQuoteType::RunningSpread,
            "upfront" => CdsQuoteType::Upfront { running_spread, settlement_days: upfront_settlement_days },
            other => {
                return Err(rmql::Error::InvalidInput { reason: format!("unknown quote type '{other}': use \"spread\" or \"upfront\"") })
            }
        };
        let spec = CdsCurveSpec {
            evaluation_date: date(evaluation_date)?,
            settlement_days: settlement_days.max(0) as u32,
            calendar: HolidayCalendar::from(names::parse_calendar(calendar)?),
            tenor: names::parse_period(tenor)?,
            payment_convention: names::parse_business_day_convention(payment_convention)?,
            rule: names::parse_date_generation_rule(rule)?,
            day_count: names::parse_day_count(day_count)?,
            last_period_day_count: None,
            rebates_accrual: true,
            recovery,
            engine: names::parse_cds_engine(engine)?,
            curve_day_count: names::parse_day_count(curve_day_count)?,
            accuracy,
            quote_type,
            quotes: maturity
                .iter()
                .zip(&spread)
                .map(|(&m, &s)| Ok(CdsQuote { maturity: date(m)?, value: s }))
                .collect::<Core<Vec<_>>>()?,
        };
        cds::bootstrap_hazard_curve(&spec, &curve.curve)
    };
    outcome(build().map(|c| {
        list!(
            node_date = c.hazard.dates().iter().map(|d| d.serial() as f64).collect::<Vec<f64>>(),
            hazard = c.hazard.values().to_vec(),
            hazard_curve = ExternalPtr::new(c.hazard.clone()),
            value = ExternalPtr::new(c)
        )
    }))
}
#[extendr]
fn compute_cds_quote_sensitivity(
    cds: ExternalPtr<Cds>,
    credit: ExternalPtr<CdsCurve>,
    curve: ExternalPtr<OisCurve>,
    evaluation_date: i32,
    engine: &str,
) -> List {
    let run = || -> Core<List> {
        let s = cds::compute_cds_sensitivity(names::parse_cds_engine(engine)?, &cds, &credit, &curve.curve, date(evaluation_date)?)?;
        Ok(list!(
            npv = s.value.npv,
            d_npv_d_recovery = s.d_npv_d_recovery,
            quote = s.quotes.iter().map(|q| q.quote as i32 + 1).collect::<Vec<i32>>(),
            maturity = s.quotes.iter().map(|q| q.maturity.serial() as f64).collect::<Vec<f64>>(),
            spread = s.quotes.iter().map(|q| q.value).collect::<Vec<f64>>(),
            d_npv = s.quotes.iter().map(|q| q.d_npv).collect::<Vec<f64>>()
        ))
    };
    outcome(run())
}
#[extendr]
fn compute_cds_maturity(trade_date: i32, tenor: &str, rule: &str) -> List {
    let run = || -> Core<f64> {
        let d = rmql::time::compute_cds_maturity(date(trade_date)?, names::parse_period(tenor)?, names::parse_date_generation_rule(rule)?)?;
        Ok(d.serial() as f64)
    };
    value_list(vec![run()])
}
// ---- PRDC ----------------------------------------------------------------------------------------
fn prdc_list(s: PrdcSensitivity) -> List {
    let (mut domestic, mut dates, mut times, mut d_npv) = (Vec::new(), Vec::new(), Vec::new(), Vec::new());
    for c in &s.curves {
        if let CurveInput::LogDiscount { date, time } = c.input {
            domestic.push(if c.domestic { "domestic" } else { "foreign" }.to_string());
            dates.push(date.serial() as f64);
            times.push(time);
            d_npv.push(c.d_npv);
        }
    }
    list!(
        npv = s.npv,
        standard_error = s.standard_error,
        fx_delta = s.fx_delta,
        fx_vega = s.fx_vega,
        curve = domestic,
        date = dates,
        time = times,
        d_npv = d_npv
    )
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_prdc_three_factor_value(
    spot: f64,
    fx_volatility: Vec<f64>,
    fx_volatility_times: Vec<f64>,
    domestic_curve: ExternalPtr<OisCurve>,
    foreign_curve: ExternalPtr<OisCurve>,
    domestic_rate: Vec<f64>,
    foreign_rate: Vec<f64>,
    correlation: Vec<f64>,
    coupon_times: Vec<f64>,
    accrual_fractions: Vec<f64>,
    fixed_rates: Vec<f64>,
    fx_base: f64,
    leverage: f64,
    subtraction: f64,
    floor: f64,
    cap: f64,
    notional: f64,
    redemption: f64,
    paths: i32,
    steps_per_year: i32,
    seed: f64,
    call_dates: Vec<i32>,
    call_price: f64,
    training_seed: f64,
    training_paths: i32,
    bump: f64,
    target: f64,
    target_coupon: &str,
    make_whole: bool,
    knock_out_level: f64,
    knock_out_dates: Vec<i32>,
) -> List {
    let run = || -> Core<List> {
        if domestic_rate.len() != 2 || foreign_rate.len() != 2 || correlation.len() != 3 {
            return Err(rmql::Error::InvalidInput {
                reason: "give each rate as (mean reversion, volatility) and three correlations".into(),
            });
        }
        let terms = PrdcTerms {
            notional,
            redemption,
            coupon_times,
            accrual_fractions,
            fixed_rates: fixed_rates.iter().map(|&r| if r.is_nan() { None } else { Some(r) }).collect(),
            fx_base,
            leverage,
            subtraction,
            floor,
            cap,
        };
        if fx_volatility.is_empty() || (!fx_volatility_times.is_empty() && fx_volatility_times.len() != fx_volatility.len()) {
            return Err(rmql::Error::InvalidInput { reason: "give one FX volatility, or one per piece's end time".into() });
        }
        let model = prdc::PrdcThreeFactor {
            spot,
            fx_volatility: fx_volatility[0],
            fx_volatility_term: (!fx_volatility_times.is_empty()).then_some(prdc::FxVolatilityTerm { times: &fx_volatility_times, volatilities: &fx_volatility }),
            domestic: &domestic_curve.curve,
            foreign: &foreign_curve.curve,
            domestic_rate: prdc::HullWhiteFactor { mean_reversion: domestic_rate[0], volatility: domestic_rate[1] },
            foreign_rate: prdc::HullWhiteFactor { mean_reversion: foreign_rate[0], volatility: foreign_rate[1] },
            correlation: [correlation[0], correlation[1], correlation[2]],
        };
        let sens = prdc::compute_prdc_three_factor_sensitivity(&terms, &model)?;
        let analytic = sens.npv;
        let effective_all: Vec<f64> = terms.coupon_times.iter().map(|&t| (model.fx_forward_variance(t) / t).sqrt()).collect();
        let parameter: Vec<String> = ["spot", "fx_volatility", "domestic_mean_reversion", "domestic_volatility", "foreign_mean_reversion", "foreign_volatility", "rho_domestic_foreign", "rho_domestic_fx", "rho_foreign_fx"].iter().map(|s| s.to_string()).collect();
        let d_parameter = vec![sens.fx_delta, sens.fx_vega, sens.domestic_mean_reversion, sens.domestic_volatility, sens.foreign_mean_reversion, sens.foreign_volatility, sens.correlation[0], sens.correlation[1], sens.correlation[2]];
        let (mut curve, mut curve_date, mut curve_time, mut d_curve) = (Vec::new(), Vec::new(), Vec::new(), Vec::new());
        for c in &sens.curves {
            if let rmql::curves::CurveInput::LogDiscount { date, time } = c.input {
                curve.push(if c.domestic { "domestic" } else { "foreign" }.to_string());
                curve_date.push(date.serial() as f64);
                curve_time.push(time);
                d_curve.push(c.d_npv);
            }
        }
        if target.is_finite() || make_whole || knock_out_level.is_finite() {
            if !call_dates.is_empty() || paths <= 0 {
                return Err(rmql::Error::InvalidInput { reason: "a target redemption or knock-out needs paths and no call dates".into() });
            }
            let coupon = match target_coupon {
                "capped" => prdc::TargetCoupon::Capped,
                "full" => prdc::TargetCoupon::Full,
                other => return Err(rmql::Error::InvalidInput { reason: format!("unknown target coupon {other:?}: use \"capped\" or \"full\"") }),
            };
            let rule = prdc::TargetRedemption { target, coupon, make_whole };
            let knock = prdc::KnockOut { level: knock_out_level, dates: knock_out_dates.iter().map(|&k| k.max(0) as usize).collect() };
            let (rule, knock) = ((target.is_finite() || make_whole).then_some(&rule), knock_out_level.is_finite().then_some(&knock));
            let r = prdc::compute_path_dependent_prdc(&terms, &model, rule, knock, paths as usize, steps_per_year.max(0) as usize, seed as u64)?;
            let ps = prdc::compute_path_dependent_prdc_sensitivity(&terms, &model, rule, knock, paths as usize, steps_per_year.max(0) as usize, seed as u64, bump)?;
            let scalars = [ps.fx_delta, ps.fx_vega, ps.domestic_mean_reversion, ps.domestic_volatility, ps.foreign_mean_reversion, ps.foreign_volatility, ps.correlation[0], ps.correlation[1], ps.correlation[2]];
            let (mut path_curve, mut path_date, mut path_time, mut path_d, mut path_se, mut path_changed) = (Vec::new(), Vec::new(), Vec::new(), Vec::new(), Vec::new(), Vec::new());
            for c in &ps.curves {
                if let rmql::curves::CurveInput::LogDiscount { date, time } = c.input {
                    path_curve.push(if c.domestic { "domestic" } else { "foreign" }.to_string());
                    path_date.push(date.serial() as f64);
                    path_time.push(time);
                    path_d.push(c.d_npv.value);
                    path_se.push(c.d_npv.standard_error);
                    path_changed.push(c.d_npv.changed_paths);
                }
            }
            return Ok(list!(
                value = r.value,
                standard_error = r.standard_error,
                analytic = analytic,
                effective_volatility = effective_all.clone(),
                parameter = parameter,
                d_parameter = d_parameter,
                curve = curve,
                curve_date = curve_date,
                curve_time = curve_time,
                d_curve = d_curve,
                plain_value = r.plain_value,
                expected_life = r.expected_life,
                target_probability = r.target_probability,
                knock_out_probability = r.knock_out_probability,
                fx_vega_term = sens.fx_vega_term.clone(),
                path_d_parameter = scalars.iter().map(|e| e.value).collect::<Vec<f64>>(),
                path_parameter_error = scalars.iter().map(|e| e.standard_error).collect::<Vec<f64>>(),
                path_parameter_changed = scalars.iter().map(|e| e.changed_paths).collect::<Vec<f64>>(),
                path_curve = path_curve,
                path_curve_date = path_date,
                path_curve_time = path_time,
                path_d_curve = path_d,
                path_curve_error = path_se,
                path_curve_changed = path_changed
            ));
        }
        if !call_dates.is_empty() {
            if paths <= 0 {
                return Err(rmql::Error::InvalidInput { reason: "a callable note needs paths".into() });
            }
            let dates: Vec<usize> = call_dates.iter().map(|&k| k.max(0) as usize).collect();
            let r = prdc::compute_callable_prdc_three_factor(&terms, &model, &dates, call_price, paths as usize, training_paths.max(0) as usize, steps_per_year.max(0) as usize, seed as u64, training_seed as u64)?;
            let cs = prdc::compute_callable_prdc_three_factor_sensitivity(
                &terms,
                &model,
                &dates,
                call_price,
                paths as usize,
                training_paths.max(0) as usize,
                steps_per_year.max(0) as usize,
                seed as u64,
                training_seed as u64,
                bump,
            )?;
            let scalars = [cs.fx_delta, cs.fx_vega, cs.domestic_mean_reversion, cs.domestic_volatility, cs.foreign_mean_reversion, cs.foreign_volatility, cs.correlation[0], cs.correlation[1], cs.correlation[2]];
            let (mut call_curve, mut call_date, mut call_time, mut call_d, mut call_se) = (Vec::new(), Vec::new(), Vec::new(), Vec::new(), Vec::new());
            for c in &cs.curves {
                if let rmql::curves::CurveInput::LogDiscount { date, time } = c.input {
                    call_curve.push(if c.domestic { "domestic" } else { "foreign" }.to_string());
                    call_date.push(date.serial() as f64);
                    call_time.push(time);
                    call_d.push(c.d_npv.value);
                    call_se.push(c.d_npv.standard_error);
                }
            }
            let effective: Vec<f64> = terms.coupon_times.iter().map(|&t| (model.fx_forward_variance(t) / t).sqrt()).collect();
            return Ok(list!(
                value = r.value,
                standard_error = r.standard_error,
                analytic = analytic,
                effective_volatility = effective,
                noncallable_value = r.noncallable_value,
                hindsight_value = r.hindsight_value,
                call_probability = r.call_probability,
                parameter = parameter,
                d_parameter = d_parameter,
                curve = curve,
                curve_date = curve_date,
                curve_time = curve_time,
                d_curve = d_curve,
                call_d_parameter = scalars.iter().map(|e| e.value).collect::<Vec<f64>>(),
                call_parameter_error = scalars.iter().map(|e| e.standard_error).collect::<Vec<f64>>(),
                call_curve = call_curve,
                call_curve_date = call_date,
                call_curve_time = call_time,
                call_d_curve = call_d,
                call_curve_error = call_se,
                fx_vega_term = sens.fx_vega_term.clone()
            ));
        }
        let (value, standard_error) = if paths > 0 {
            prdc::compute_prdc_three_factor_monte_carlo(&terms, &model, paths as usize, steps_per_year.max(0) as usize, seed as u64)?
        } else {
            (analytic, 0.0)
        };
        let effective: Vec<f64> = terms.coupon_times.iter().map(|&t| (model.fx_forward_variance(t) / t).sqrt()).collect();
        Ok(list!(value = value, standard_error = standard_error, analytic = analytic, effective_volatility = effective, parameter = parameter, d_parameter = d_parameter, curve = curve, curve_date = curve_date, curve_time = curve_time, d_curve = d_curve, fx_vega_term = sens.fx_vega_term.clone()))
    };
    outcome(run())
}
fn fx_delta_type(s: &str) -> Core<fx_smile::FxDeltaType> {
    Ok(match s {
        "spot" => fx_smile::FxDeltaType::Spot,
        "forward" => fx_smile::FxDeltaType::Forward,
        "premium_adjusted_spot" => fx_smile::FxDeltaType::PremiumAdjustedSpot,
        "premium_adjusted_forward" => fx_smile::FxDeltaType::PremiumAdjustedForward,
        other => {
            return Err(rmql::Error::InvalidInput {
                reason: format!("unknown delta type {other:?}: use \"spot\", \"forward\", \"premium_adjusted_spot\" or \"premium_adjusted_forward\""),
            })
        }
    })
}
fn fx_atm_type(s: &str) -> Core<fx_smile::FxAtmType> {
    Ok(match s {
        "spot" => fx_smile::FxAtmType::Spot,
        "forward" => fx_smile::FxAtmType::Forward,
        "delta_neutral" => fx_smile::FxAtmType::DeltaNeutral,
        "put_call_50" => fx_smile::FxAtmType::PutCall50,
        other => {
            return Err(rmql::Error::InvalidInput {
                reason: format!("unknown ATM type {other:?}: use \"spot\", \"forward\", \"delta_neutral\" or \"put_call_50\""),
            })
        }
    })
}
fn fx_option_type(s: &str) -> Core<rmql::options::OptionType> {
    match s {
        "call" => Ok(rmql::options::OptionType::Call),
        "put" => Ok(rmql::options::OptionType::Put),
        other => Err(rmql::Error::InvalidInput { reason: format!("unknown option type {other:?}: use \"call\" or \"put\"") }),
    }
}
/// The smile of the R list made by `create_fx_smile()`: `conventions` holds the delta, ATM and ATM
/// delta types, then (for a switch) the long-term ones; `volatilities` is by expiry (rows).
#[allow(clippy::too_many_arguments)]
fn fx_smile_of<'c>(
    spot: f64,
    domestic: &'c rmql::curves::YieldCurve,
    foreign: &'c rmql::curves::YieldCurve,
    expiries: &[f64],
    put_deltas: &[f64],
    call_deltas: &[f64],
    has_atm: bool,
    volatilities: &[f64],
    conventions: &[String],
    switch_time: f64,
    interpolation: &str,
    flat_strike_extrapolation: bool,
) -> Core<fx_smile::FxSmileSurface<'c>> {
    let pillars = put_deltas.len() + call_deltas.len() + usize::from(has_atm);
    if conventions.len() != 6 || pillars == 0 || volatilities.len() != expiries.len() * pillars {
        return Err(rmql::Error::InvalidInput { reason: format!("give {pillars} volatilities for each of the {} expiries", expiries.len()) });
    }
    let convention = |k: usize| -> Core<fx_smile::FxSmileConventions> {
        Ok(fx_smile::FxSmileConventions {
            delta_type: fx_delta_type(&conventions[k])?,
            atm_type: fx_atm_type(&conventions[k + 1])?,
            atm_delta_type: fx_delta_type(&conventions[k + 2])?,
        })
    };
    Ok(fx_smile::FxSmileSurface {
        spot,
        domestic,
        foreign,
        expiries: expiries.to_vec(),
        put_deltas: put_deltas.to_vec(),
        call_deltas: call_deltas.to_vec(),
        has_atm,
        // by rows: expiry i's pillars are volatilities[i * pillars..(i + 1) * pillars]
        volatilities: volatilities.chunks(pillars).map(|c| c.to_vec()).collect(),
        conventions: convention(0)?,
        long_term: if switch_time.is_finite() { Some((switch_time, convention(3)?)) } else { None },
        interpolation: match interpolation {
            "linear" => fx_smile::SmileInterpolation::Linear,
            "cubic_spline" => fx_smile::SmileInterpolation::CubicSpline,
            other => return Err(rmql::Error::InvalidInput { reason: format!("unknown smile interpolation {other:?}: use \"linear\" or \"cubic_spline\"") }),
        },
        flat_strike_extrapolation,
    })
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_fx_delta_conversion(
    kind: &str,
    option: &str,
    delta_type: &str,
    spot: f64,
    domestic_discount: f64,
    foreign_discount: f64,
    std_dev: f64,
    input: f64,
    atm_type: &str,
) -> List {
    let run = || -> Core<List> {
        let calculator = fx_smile::FxDeltaCalculator {
            option: fx_option_type(option)?,
            delta_type: fx_delta_type(delta_type)?,
            spot,
            domestic_discount,
            foreign_discount,
            std_dev,
        };
        let value = match kind {
            "strike_from_delta" => calculator.strike_from_delta(input)?,
            "delta_from_strike" => calculator.delta_from_strike(input)?,
            _ => calculator.atm_strike(fx_atm_type(atm_type)?)?,
        };
        Ok(list!(value = value))
    };
    outcome(run())
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_fx_smile_values(
    spot: f64,
    domestic_curve: ExternalPtr<OisCurve>,
    foreign_curve: ExternalPtr<OisCurve>,
    expiries: Vec<f64>,
    put_deltas: Vec<f64>,
    call_deltas: Vec<f64>,
    has_atm: bool,
    volatilities: Vec<f64>,
    conventions: Vec<String>,
    switch_time: f64,
    interpolation: &str,
    flat_strike_extrapolation: bool,
    times: Vec<f64>,
    strikes: Vec<f64>,
    smile_time: f64,
) -> List {
    let run = || -> Core<List> {
        let surface = fx_smile_of(
            spot, &domestic_curve.curve, &foreign_curve.curve, &expiries, &put_deltas, &call_deltas, has_atm, &volatilities, &conventions,
            switch_time, interpolation, flat_strike_extrapolation,
        )?;
        surface.check()?;
        if times.len() != strikes.len() {
            return Err(rmql::Error::InvalidInput { reason: "give one strike per time".into() });
        }
        let vols = times.iter().zip(&strikes).map(|(&t, &k)| surface.volatility(t, k)).collect::<Core<Vec<f64>>>()?;
        let (pillar_strikes, pillar_vols) = if smile_time.is_finite() {
            let s = surface.smile_at(smile_time)?;
            (s.strikes, s.volatilities)
        } else {
            (Vec::new(), Vec::new())
        };
        Ok(list!(volatility = vols, smile_strike = pillar_strikes, smile_volatility = pillar_vols))
    };
    outcome(run())
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_prdc_smile_value(
    spot: f64,
    domestic_curve: ExternalPtr<OisCurve>,
    foreign_curve: ExternalPtr<OisCurve>,
    expiries: Vec<f64>,
    put_deltas: Vec<f64>,
    call_deltas: Vec<f64>,
    has_atm: bool,
    volatilities: Vec<f64>,
    conventions: Vec<String>,
    switch_time: f64,
    interpolation: &str,
    flat_strike_extrapolation: bool,
    coupon_times: Vec<f64>,
    accrual_fractions: Vec<f64>,
    fixed_rates: Vec<f64>,
    fx_base: f64,
    leverage: f64,
    subtraction: f64,
    floor: f64,
    cap: f64,
    notional: f64,
    redemption: f64,
) -> List {
    let run = || -> Core<List> {
        let surface = fx_smile_of(
            spot, &domestic_curve.curve, &foreign_curve.curve, &expiries, &put_deltas, &call_deltas, has_atm, &volatilities, &conventions,
            switch_time, interpolation, flat_strike_extrapolation,
        )?;
        let terms = PrdcTerms {
            notional,
            redemption,
            coupon_times,
            accrual_fractions,
            fixed_rates: fixed_rates.iter().map(|&r| if r.is_nan() { None } else { Some(r) }).collect(),
            fx_base,
            leverage,
            subtraction,
            floor,
            cap,
        };
        let s = prdc::compute_prdc_smile_value(&terms, &surface)?;
        let na = |x: Option<f64>| x.unwrap_or(f64::NAN);
        Ok(list!(
            value = s.npv,
            fx_delta = s.fx_delta,
            fx_delta_sticky_strike = s.fx_delta_sticky_strike,
            fx_vega = s.fx_vega,
            time = s.coupons.iter().map(|c| c.time).collect::<Vec<f64>>(),
            forward = s.coupons.iter().map(|c| c.forward).collect::<Vec<f64>>(),
            floor_strike = s.coupons.iter().map(|c| na(c.floor_strike)).collect::<Vec<f64>>(),
            floor_volatility = s.coupons.iter().map(|c| na(c.floor_volatility)).collect::<Vec<f64>>(),
            cap_strike = s.coupons.iter().map(|c| na(c.cap_strike)).collect::<Vec<f64>>(),
            cap_volatility = s.coupons.iter().map(|c| na(c.cap_volatility)).collect::<Vec<f64>>(),
            rate = s.coupons.iter().map(|c| c.rate).collect::<Vec<f64>>(),
            coupon_value = s.coupons.iter().map(|c| c.value).collect::<Vec<f64>>(),
            pillar_vega = s.pillar_vega.iter().flatten().copied().collect::<Vec<f64>>()
        ))
    };
    outcome(run())
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn calibrate_prdc_fx_volatility(
    spot: f64,
    domestic_curve: ExternalPtr<OisCurve>,
    foreign_curve: ExternalPtr<OisCurve>,
    domestic_rate: Vec<f64>,
    foreign_rate: Vec<f64>,
    correlation: Vec<f64>,
    maturities: Vec<f64>,
    volatilities: Vec<f64>,
    term_structure: bool,
) -> List {
    let run = || -> Core<List> {
        if domestic_rate.len() != 2 || foreign_rate.len() != 2 || correlation.len() != 3 {
            return Err(rmql::Error::InvalidInput {
                reason: "give each rate as (mean reversion, volatility) and three correlations".into(),
            });
        }
        let model = prdc::PrdcThreeFactor {
            spot,
            fx_volatility: 1.0,
            fx_volatility_term: None,
            domestic: &domestic_curve.curve,
            foreign: &foreign_curve.curve,
            domestic_rate: prdc::HullWhiteFactor { mean_reversion: domestic_rate[0], volatility: domestic_rate[1] },
            foreign_rate: prdc::HullWhiteFactor { mean_reversion: foreign_rate[0], volatility: foreign_rate[1] },
            correlation: [correlation[0], correlation[1], correlation[2]],
        };
        if term_structure {
            let fit = prdc::calibrate_prdc_fx_volatility_term(&model, &maturities, &volatilities)?;
            let rmse = (fit.model_volatilities.iter().zip(&volatilities).map(|(m, v)| (m - v).powi(2)).sum::<f64>() / volatilities.len() as f64).sqrt();
            return Ok(list!(fx_volatility = fit.volatilities, fx_volatility_times = fit.times, model_volatilities = fit.model_volatilities, root_mean_square_error = rmse));
        }
        let fit = prdc::calibrate_prdc_fx_volatility(&model, &maturities, &volatilities)?;
        Ok(list!(fx_volatility = fit.fx_volatility, fx_volatility_times = Vec::<f64>::new(), model_volatilities = fit.model_volatilities, root_mean_square_error = fit.root_mean_square_error))
    };
    outcome(run())
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_prdc_value(
    spot: f64,
    volatility: f64,
    domestic_curve: ExternalPtr<OisCurve>,
    foreign_curve: ExternalPtr<OisCurve>,
    coupon_times: Vec<f64>,
    accrual_fractions: Vec<f64>,
    fixed_rates: Vec<f64>,
    fx_base: f64,
    leverage: f64,
    subtraction: f64,
    floor: f64,
    cap: f64,
    notional: f64,
    redemption: f64,
    paths: f64,
    seed: f64,
    antithetic: bool,
    threads: i32,
) -> List {
    let terms = PrdcTerms {
        notional,
        redemption,
        coupon_times,
        accrual_fractions,
        // NaN means the formula on this date
        fixed_rates: fixed_rates.iter().map(|&r| if r.is_nan() { None } else { Some(r) }).collect(),
        fx_base,
        leverage,
        subtraction,
        floor,
        cap,
    };
    let result = if paths > 0.0 {
        prdc::compute_prdc_monte_carlo(
            &terms,
            spot,
            volatility,
            &domestic_curve.curve,
            &foreign_curve.curve,
            &PrdcMonteCarlo { paths: paths as u64, seed: seed as u64, antithetic, threads: threads.max(0) as usize },
        )
    } else {
        prdc::compute_prdc_analytic(&terms, spot, volatility, &domestic_curve.curve, &foreign_curve.curve)
    };
    outcome(result.map(prdc_list))
}
// ---- options --------------------------------------------------------------------------------
fn option_inputs(values: [f64; 6]) -> OptionInputs {
    let [spot, strike, rate, dividend_yield, volatility, time] = values;
    OptionInputs { spot, strike, rate, dividend_yield, volatility, time }
}
/// Columns of `f(row)`, with NA and a message where a row fails.
fn table<const N: usize>(n: usize, f: impl Fn(usize) -> Core<[f64; N]>) -> (Vec<Vec<f64>>, Vec<String>) {
    let mut columns = vec![Vec::with_capacity(n); N];
    let mut errors = Vec::with_capacity(n);
    for i in 0..n {
        match f(i) {
            Ok(row) => {
                columns.iter_mut().zip(row).for_each(|(c, v)| c.push(v));
                errors.push(String::new());
            }
            Err(e) => {
                columns.iter_mut().for_each(|c| c.push(na_real()));
                errors.push(e.to_string());
            }
        }
    }
    (columns, errors)
}
fn greeks_row(g: Greeks) -> [f64; 8] {
    [g.value, g.delta, g.gamma, g.vega, g.rho, g.dividend_rho, g.theta, g.strike_sensitivity]
}
fn greeks_list(n: usize, f: impl Fn(usize) -> Core<Greeks>) -> List {
    let (columns, error) = table(n, |i| f(i).map(greeks_row));
    list!(
        value = columns[0].clone(),
        delta = columns[1].clone(),
        gamma = columns[2].clone(),
        vega = columns[3].clone(),
        rho = columns[4].clone(),
        dividend_rho = columns[5].clone(),
        theta = columns[6].clone(),
        strike_sensitivity = columns[7].clone(),
        error = error
    )
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_european_option_value(
    option_type: Vec<String>,
    spot: Vec<f64>,
    strike: Vec<f64>,
    rate: Vec<f64>,
    dividend_yield: Vec<f64>,
    volatility: Vec<f64>,
    time: Vec<f64>,
) -> List {
    greeks_list(spot.len(), |i| {
        options::compute_european_greeks(
            names::parse_option_type(&option_type[i])?,
            &option_inputs([spot[i], strike[i], rate[i], dividend_yield[i], volatility[i], time[i]]),
        )
    })
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_barrier_option_value(
    option_type: Vec<String>,
    barrier_type: Vec<String>,
    spot: Vec<f64>,
    strike: Vec<f64>,
    barrier: Vec<f64>,
    rebate: Vec<f64>,
    rate: Vec<f64>,
    dividend_yield: Vec<f64>,
    volatility: Vec<f64>,
    time: Vec<f64>,
) -> List {
    greeks_list(spot.len(), |i| {
        options::compute_barrier_greeks(
            names::parse_option_type(&option_type[i])?,
            names::parse_barrier_type(&barrier_type[i])?,
            barrier[i],
            rebate[i],
            &option_inputs([spot[i], strike[i], rate[i], dividend_yield[i], volatility[i], time[i]]),
        )
    })
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_binomial_option_value(
    option_type: Vec<String>,
    exercise: Vec<String>,
    spot: Vec<f64>,
    strike: Vec<f64>,
    rate: Vec<f64>,
    dividend_yield: Vec<f64>,
    volatility: Vec<f64>,
    time: Vec<f64>,
    steps: Vec<i32>,
) -> List {
    greeks_list(spot.len(), |i| {
        options::compute_binomial_greeks(
            names::parse_option_type(&option_type[i])?,
            names::parse_exercise(&exercise[i])?,
            &option_inputs([spot[i], strike[i], rate[i], dividend_yield[i], volatility[i], time[i]]),
            steps[i].max(0) as usize,
        )
    })
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_american_approximation_value(
    method: Vec<String>,
    option_type: Vec<String>,
    spot: Vec<f64>,
    strike: Vec<f64>,
    rate: Vec<f64>,
    dividend_yield: Vec<f64>,
    volatility: Vec<f64>,
    time: Vec<f64>,
) -> List {
    greeks_list(spot.len(), |i| {
        let method = match method[i].as_str() {
            "barone_adesi_whaley" => AmericanApproximation::BaroneAdesiWhaley,
            "bjerksund_stensland" => AmericanApproximation::BjerksundStensland,
            other => {
                return Err(rmql::Error::InvalidInput {
                    reason: format!("method must be barone_adesi_whaley or bjerksund_stensland, not {other}"),
                })
            }
        };
        american_approximations::compute_american_approximation_greeks(
            method,
            names::parse_option_type(&option_type[i])?,
            &option_inputs([spot[i], strike[i], rate[i], dividend_yield[i], volatility[i], time[i]]),
        )
    })
}
#[extendr]
fn compute_forward_option_value(
    model: Vec<String>,
    option_type: Vec<String>,
    forward: Vec<f64>,
    strike: Vec<f64>,
    volatility: Vec<f64>,
    time: Vec<f64>,
    discount: Vec<f64>,
) -> List {
    let (columns, error) = table(forward.len(), |i| {
        let g = options::compute_forward_greeks(
            names::parse_forward_model(&model[i])?,
            names::parse_option_type(&option_type[i])?,
            &options::ForwardInputs {
                forward: forward[i],
                strike: strike[i],
                volatility: volatility[i],
                time: time[i],
                discount: discount[i],
            },
        )?;
        Ok([g.value, g.delta_forward, g.gamma_forward, g.vega, g.d_time, g.d_discount, g.strike_sensitivity])
    });
    list!(
        value = columns[0].clone(),
        delta_forward = columns[1].clone(),
        gamma_forward = columns[2].clone(),
        vega = columns[3].clone(),
        d_time = columns[4].clone(),
        d_discount = columns[5].clone(),
        strike_sensitivity = columns[6].clone(),
        error = error
    )
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_implied_volatility(
    option_type: Vec<String>,
    price: Vec<f64>,
    spot: Vec<f64>,
    strike: Vec<f64>,
    rate: Vec<f64>,
    dividend_yield: Vec<f64>,
    time: Vec<f64>,
    accuracy: f64,
    max_evaluations: i32,
) -> List {
    let rows = (0..spot.len())
        .map(|i| {
            options::compute_implied_volatility(
                names::parse_option_type(&option_type[i])?,
                price[i],
                &option_inputs([spot[i], strike[i], rate[i], dividend_yield[i], 0.2, time[i]]),
                accuracy,
                max_evaluations.max(0) as usize,
            )
        })
        .collect();
    value_list(rows)
}
// ---- LMM building blocks ----------------------------------------------------------------------------
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_caplet_value(
    model: &str,
    forward: Vec<f64>,
    strike: Vec<f64>,
    volatility: Vec<f64>,
    expiry: Vec<f64>,
    accrual: Vec<f64>,
    discount_factor: Vec<f64>,
    notional: Vec<f64>,
) -> List {
    let model = match names::parse_forward_model(model) {
        Ok(m) => m,
        Err(e) => return failure(e),
    };
    let rows = (0..forward.len())
        .map(|i| {
            let terms = CapletTerms {
                forward: forward[i],
                strike: strike[i],
                volatility: volatility[i],
                expiry: expiry[i],
                accrual: accrual[i],
                discount_factor: discount_factor[i],
                notional: notional[i],
            };
            lmm::compute_caplet_value(model, &terms)
        })
        .collect();
    value_list(rows)
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_backward_caplet_value(
    model: &str,
    forward: Vec<f64>,
    strike: Vec<f64>,
    volatility: Vec<f64>,
    time_to_start: Vec<f64>,
    time_to_end: Vec<f64>,
    accrual: Vec<f64>,
    discount_factor: Vec<f64>,
    notional: Vec<f64>,
) -> List {
    let model = match names::parse_forward_model(model) {
        Ok(m) => m,
        Err(e) => return failure(e),
    };
    let rows = (0..forward.len())
        .map(|i| {
            let terms = rmql::fmm::BackwardCapletTerms {
                forward: forward[i],
                strike: strike[i],
                volatility: volatility[i],
                time_to_start: time_to_start[i],
                time_to_end: time_to_end[i],
                accrual: accrual[i],
                discount_factor: discount_factor[i],
                notional: notional[i],
            };
            rmql::fmm::compute_backward_caplet_value(model, &terms)
        })
        .collect();
    value_list(rows)
}
fn lmm_spec(times: &[f64], forwards: &[f64], volatilities: &[f64], correlation: &[f64], discount_start: f64, backward_looking: bool, model: &str, grid: &[f64], factors: i32, measure: &str, discretization: &str) -> Core<rmql::lmm_market::LmmSpec> {
    let discretization = match discretization {
        "euler" => rmql::lmm_market::Discretization::Euler,
        "predictor_corrector" => rmql::lmm_market::Discretization::PredictorCorrector,
        other => return Err(rmql::Error::InvalidInput { reason: format!("unknown discretization {other:?}: use \"euler\" or \"predictor_corrector\"") }),
    };
    let measure = match measure {
        "spot" => rmql::lmm_market::Measure::Spot,
        "terminal" => rmql::lmm_market::Measure::Terminal,
        other => return Err(rmql::Error::InvalidInput { reason: format!("unknown measure {other:?}: use \"spot\" or \"terminal\"") }),
    };
    Ok(rmql::lmm_market::LmmSpec {
        times: times.to_vec(),
        forwards: forwards.to_vec(),
        volatilities: volatilities.to_vec(),
        correlation: correlation.to_vec(),
        discount_start,
        backward_looking,
        model: names::parse_forward_model(model)?,
        volatility_grid: if grid.is_empty() { None } else { Some(grid.to_vec()) },
        factors: if factors > 0 { Some(factors as usize) } else { None },
        measure,
        discretization,
    })
}
#[extendr]
fn create_exponential_correlation(times: Vec<f64>, beta: f64) -> List {
    outcome(rmql::lmm_market::create_exponential_correlation(&times, beta).map(|c| list!(value = c)))
}
#[extendr]
fn create_reduced_correlation(correlation: Vec<f64>, n: i32, factors: i32) -> List {
    outcome(rmql::lmm_market::create_reduced_correlation(&correlation, n.max(0) as usize, factors.max(0) as usize).map(|c| list!(value = c)))
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_lmm_monte_carlo(
    times: Vec<f64>,
    forwards: Vec<f64>,
    volatilities: Vec<f64>,
    correlation: Vec<f64>,
    discount_start: f64,
    backward_looking: bool,
    model: &str,
    volatility_grid: Vec<f64>,
    factors: i32,
    measure: &str,
    discretization: &str,
    kind: Vec<String>,
    start: Vec<i32>,
    end: Vec<i32>,
    strike: Vec<f64>,
    expiry: Vec<f64>,
    paths: i32,
    steps_per_period: i32,
    seed: f64,
) -> List {
    let run = || -> Core<List> {
        let spec = lmm_spec(&times, &forwards, &volatilities, &correlation, discount_start, backward_looking, model, &volatility_grid, factors, measure, discretization)?;
        let (paths, steps) = (paths.max(0) as usize, steps_per_period.max(0) as usize);
        let simulated = rmql::lmm_market::generate_lmm_paths(&spec, paths, steps, seed as u64)?;
        let (mut value, mut standard_error, mut formula) = (Vec::new(), Vec::new(), Vec::new());
        for i in 0..kind.len() {
            formula.push(if kind[i] == "caplet" { rmql::lmm_market::compute_lmm_caplet_formula(&spec, start[i] as usize, strike[i])? } else { f64::NAN });
            let (a, b) = (start[i] as usize, end[i] as usize);
            let e = match kind[i].as_str() {
                "swaption" if expiry[i].is_nan() => rmql::lmm_market::compute_lmm_swaption_value(&spec, &simulated, a, b, strike[i])?,
                "swaption" => {
                    // exercised between tenor dates: paths observed at that time
                    let observed = rmql::lmm_market::generate_lmm_paths_observed(&spec, paths, steps, seed as u64, Some(expiry[i]))?;
                    rmql::lmm_market::compute_lmm_swaption_value_at(&spec, &observed, a, b, strike[i])?
                }
                "caplet" => rmql::lmm_market::compute_lmm_caplet_value(&spec, &simulated, a, strike[i])?,
                other => return Err(rmql::Error::InvalidInput { reason: format!("type must be swaption or caplet, not {other}") }),
            };
            value.push(e.value);
            standard_error.push(e.standard_error);
        }
        Ok(list!(value = value, standard_error = standard_error, formula = formula))
    };
    outcome(run())
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn generate_lmm_paths(
    times: Vec<f64>,
    forwards: Vec<f64>,
    volatilities: Vec<f64>,
    correlation: Vec<f64>,
    discount_start: f64,
    backward_looking: bool,
    model: &str,
    volatility_grid: Vec<f64>,
    factors: i32,
    measure: &str,
    discretization: &str,
    paths: i32,
    steps_per_period: i32,
    seed: f64,
) -> List {
    let run = || -> Core<List> {
        let spec = lmm_spec(&times, &forwards, &volatilities, &correlation, discount_start, backward_looking, model, &volatility_grid, factors, measure, discretization)?;
        let p = rmql::lmm_market::generate_lmm_paths(&spec, paths.max(0) as usize, steps_per_period.max(0) as usize, seed as u64)?;
        // R's array order: path fastest, then time, then forward
        let (n_paths, n) = (p.state.len(), forwards.len());
        let mut state = vec![f64::NAN; n_paths * (n + 1) * n];
        for (path, s) in p.state.iter().enumerate() {
            for (k, row) in s.iter().enumerate() {
                for (i, v) in row.iter().enumerate() {
                    state[path + n_paths * (k + (n + 1) * i)] = *v;
                }
            }
        }
        let mut numeraire = vec![0.0; n_paths * (n + 1)];
        for (path, b) in p.numeraire.iter().enumerate() {
            for (k, v) in b.iter().enumerate() {
                numeraire[path + n_paths * k] = *v;
            }
        }
        Ok(list!(state = state, numeraire = numeraire))
    };
    outcome(run())
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_rebonato_swaption_volatility(
    times: Vec<f64>,
    forwards: Vec<f64>,
    volatilities: Vec<f64>,
    correlation: Vec<f64>,
    discount_start: f64,
    backward_looking: bool,
    model: &str,
    volatility_grid: Vec<f64>,
    factors: i32,
    measure: &str,
    discretization: &str,
    start: Vec<i32>,
    end: Vec<i32>,
    strike: Vec<f64>,
    expiry: Vec<f64>,
) -> List {
    let run = || -> Core<List> {
        let spec = lmm_spec(&times, &forwards, &volatilities, &correlation, discount_start, backward_looking, model, &volatility_grid, factors, measure, discretization)?;
        let (mut vol, mut black) = (Vec::new(), Vec::new());
        for i in 0..start.len() {
            let (a, b) = (start[i] as usize, end[i] as usize);
            // NaN: exercised at the swap's start
            let t = if expiry[i].is_nan() { times.get(a).copied().unwrap_or(f64::NAN) } else { expiry[i] };
            let v = rmql::lmm_market::compute_rebonato_swaption_volatility_at(&spec, a, b, t)?;
            // a strike of 0 or less asks for the volatility only
            black.push(if strike[i] > 0.0 { rmql::lmm_market::compute_formula_swaption_value_at(&spec, a, b, strike[i], v, t)? } else { f64::NAN });
            vol.push(v);
        }
        Ok(list!(volatility = vol, black_value = black))
    };
    outcome(run())
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn calibrate_lmm_correlation(
    times: Vec<f64>,
    forwards: Vec<f64>,
    volatilities: Vec<f64>,
    discount_start: f64,
    model: &str,
    volatility_grid: Vec<f64>,
    factors: i32,
    measure: &str,
    discretization: &str,
    start: Vec<i32>,
    end: Vec<i32>,
    volatility: Vec<f64>,
    beta_max: f64,
) -> List {
    let run = || -> Core<List> {
        let n = forwards.len();
        let identity: Vec<f64> = (0..n * n).map(|k| if k / n == k % n { 1.0 } else { 0.0 }).collect();
        let spec = lmm_spec(&times, &forwards, &volatilities, &identity, discount_start, false, model, &volatility_grid, factors, measure, discretization)?;
        let quotes: Vec<_> = (0..start.len())
            .map(|i| rmql::lmm_market::SwaptionQuote { start: start[i] as usize, end: end[i] as usize, volatility: volatility[i] })
            .collect();
        let fit = rmql::lmm_market::calibrate_lmm_correlation(&spec, &quotes, beta_max)?;
        Ok(list!(beta = fit.beta, fitted = fit.fitted, root_mean_square_error = fit.root_mean_square_error))
    };
    outcome(run())
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn calibrate_lmm_volatilities(
    times: Vec<f64>,
    forwards: Vec<f64>,
    volatilities: Vec<f64>,
    correlation: Vec<f64>,
    discount_start: f64,
    backward_looking: bool,
    model: &str,
    volatility_grid: Vec<f64>,
    factors: i32,
    measure: &str,
    discretization: &str,
    start: Vec<i32>,
    end: Vec<i32>,
    volatility: Vec<f64>,
) -> List {
    let run = || -> Core<List> {
        let spec = lmm_spec(&times, &forwards, &volatilities, &correlation, discount_start, backward_looking, model, &volatility_grid, factors, measure, discretization)?;
        let quotes: Vec<_> = (0..start.len())
            .map(|i| rmql::lmm_market::SwaptionQuote { start: start[i].max(0) as usize, end: end[i].max(0) as usize, volatility: volatility[i] })
            .collect();
        let fit = rmql::lmm_market::calibrate_lmm_volatilities(&spec, &quotes)?;
        Ok(list!(grid = fit.spec.volatility_grid.unwrap_or_default(), fitted = fit.fitted, max_error = fit.max_error))
    };
    outcome(run())
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_lmm_bermudan_swaption(
    times: Vec<f64>,
    forwards: Vec<f64>,
    volatilities: Vec<f64>,
    correlation: Vec<f64>,
    discount_start: f64,
    backward_looking: bool,
    model: &str,
    volatility_grid: Vec<f64>,
    factors: i32,
    measure: &str,
    discretization: &str,
    exercise: Vec<i32>,
    end: i32,
    strike: f64,
    payer: bool,
    paths: i32,
    steps_per_period: i32,
    seed: f64,
    training_seed: f64,
) -> List {
    let run = || -> Core<List> {
        let spec = lmm_spec(&times, &forwards, &volatilities, &correlation, discount_start, backward_looking, model, &volatility_grid, factors, measure, discretization)?;
        let (paths, steps) = (paths.max(0) as usize, steps_per_period.max(0) as usize);
        let training = rmql::lmm_market::generate_lmm_paths(&spec, paths, steps, training_seed as u64)?;
        let evaluation = rmql::lmm_market::generate_lmm_paths(&spec, paths, steps, seed as u64)?;
        let dates: Vec<usize> = exercise.iter().map(|&k| k.max(0) as usize).collect();
        let r = rmql::lmm_market::compute_lmm_bermudan_swaption(&spec, &training, &evaluation, &dates, end.max(0) as usize, strike, payer)?;
        Ok(list!(
            value = r.value,
            standard_error = r.standard_error,
            hindsight_value = r.hindsight_value,
            european_value = r.european.iter().map(|e| e.value).collect::<Vec<_>>(),
            european_standard_error = r.european.iter().map(|e| e.standard_error).collect::<Vec<_>>(),
            exercised_paths = r.exercised_paths.iter().map(|&c| c as i32).collect::<Vec<_>>(),
            unexercised_paths = r.unexercised_paths as i32
        ))
    };
    outcome(run())
}
#[extendr]
fn compute_backward_period_state(
    curve: ExternalPtr<OisCurve>,
    start_date: i32,
    end_date: i32,
    evaluation_date: i32,
    fixing_dates: Vec<i32>,
    fixing_rates: Vec<f64>,
) -> List {
    let run = || -> Core<List> {
        let fixings = fixings_of(&fixing_dates, &fixing_rates)?;
        let s = rmql::fmm::compute_backward_period_state(
            &curve.spec.index,
            date(start_date)?,
            date(end_date)?,
            date(evaluation_date)?,
            &fixings,
            &curve.curve,
        )?;
        Ok(list!(realized = s.realized, forward = s.rate, accrual = s.accrual, fixed_days = s.fixed_days as i32, days = s.days as i32))
    };
    outcome(run())
}
#[extendr]
fn compute_backward_forward_rate(realized: Vec<f64>, discount_start: Vec<f64>, discount_end: Vec<f64>, accrual: Vec<f64>) -> List {
    let rows = (0..realized.len())
        .map(|i| rmql::fmm::compute_backward_forward_rate(realized[i], discount_start[i], discount_end[i], accrual[i]))
        .collect();
    value_list(rows)
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_caplet_from_normals(
    normals: Vec<f64>,
    forward: f64,
    strike: f64,
    volatility: f64,
    expiry: f64,
    accrual: f64,
    discount_factor: f64,
    notional: f64,
) -> List {
    let terms = CapletTerms { forward, strike, volatility, expiry, accrual, discount_factor, notional };
    outcome(lmm::compute_caplet_from_normals(&terms, &normals).map(|s| {
        list!(value = s.value, standard_error = s.standard_error, paths = s.paths as i32)
    }))
}
/// Normals and the correlation come by rows.
#[extendr]
fn compute_correlated_normals(normals: Vec<f64>, correlation: Vec<f64>, dimension: i32) -> List {
    outcome(lmm::compute_correlated_normals(&normals, &correlation, dimension.max(0) as usize).map(|v| list!(values = v)))
}
#[extendr]
fn generate_correlated_normals(correlation: Vec<f64>, dimension: i32, count: f64, seed: f64) -> List {
    let run = || -> Core<List> {
        let v = lmm::generate_correlated_normals(&correlation, dimension.max(0) as usize, count.max(0.0) as usize, seed as u64)?;
        Ok(list!(values = v))
    };
    outcome(run())
}
// ---- mortgage-backed securities --------------------------------------------------------------------
/// The terms in the order of `create_mbs_pass_through()`: balance, mortgage rate, pass-through rate,
/// months, PSA multiplier, sensitivity, refinancing cost, CPR cap.
fn mbs_terms(values: &[f64], amortization: &str) -> Core<PassThroughTerms> {
    let invalid = |reason: String| rmql::Error::InvalidInput { reason };
    if values.len() != 8 {
        return Err(invalid(format!("a pass-through needs 8 numbers, not {}", values.len())));
    }
    let amortization = match amortization {
        "fixed_payment" => Amortization::FixedPayment,
        "reamortized" => Amortization::Reamortized,
        other => return Err(invalid(format!("amortization must be fixed_payment or reamortized, not {other}"))),
    };
    if !(values[3] >= 1.0) || values[3].fract() != 0.0 {
        return Err(invalid(format!("months must be a whole number, not {}", values[3])));
    }
    let terms = PassThroughTerms {
        original_balance: values[0],
        mortgage_rate: values[1],
        pass_through_rate: values[2],
        months: values[3] as usize,
        psa_multiplier: values[4],
        incentive_sensitivity: values[5],
        refinancing_cost: values[6],
        cpr_cap: values[7],
        amortization,
    };
    terms.check()?;
    Ok(terms)
}
#[extendr]
fn check_mbs_pass_through(terms: Vec<f64>, amortization: &str) -> List {
    outcome(mbs_terms(&terms, amortization).map(|_| list!(valid = true)))
}
#[extendr]
fn compute_mbs_cashflows(terms: Vec<f64>, amortization: &str, refinance_rates: Vec<f64>) -> List {
    let run = || -> Core<List> {
        let c = mbs::compute_mbs_cashflows(&mbs_terms(&terms, amortization)?, &refinance_rates)?;
        Ok(list!(
            begin_balance = c.begin_balance,
            refinance_rate = c.refinance_rate,
            cpr = c.cpr,
            smm = c.smm,
            interest = c.interest,
            scheduled_principal = c.scheduled_principal,
            prepaid_principal = c.prepaid_principal,
            end_balance = c.end_balance,
            cashflow = c.cashflow
        ))
    };
    outcome(run())
}
/// Rates come by rows: path 1's months, then path 2's.
#[extendr]
fn compute_mbs_path_values(terms: Vec<f64>, amortization: &str, short_rates: Vec<f64>, refinance_rates: Vec<f64>, paths: i32, oas: f64) -> List {
    let run = || -> Core<List> {
        let terms = mbs_terms(&terms, amortization)?;
        let rates = RatePaths { short_rates: &short_rates, refinance_rates: &refinance_rates, paths: paths.max(0) as usize };
        let v = mbs::compute_mbs_path_values(&terms, &rates, oas)?;
        Ok(list!(price = v.prices, weighted_average_life = v.weighted_average_lives))
    };
    outcome(run())
}
#[extendr]
fn compute_mbs_oas(terms: Vec<f64>, amortization: &str, short_rates: Vec<f64>, refinance_rates: Vec<f64>, paths: i32, price: f64) -> List {
    let run = || -> Core<List> {
        let terms = mbs_terms(&terms, amortization)?;
        let rates = RatePaths { short_rates: &short_rates, refinance_rates: &refinance_rates, paths: paths.max(0) as usize };
        Ok(list!(value = mbs::compute_mbs_oas(&terms, &rates, price)?))
    };
    outcome(run())
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn generate_hull_white_monthly_rates(paths: i32, months: i32, flat_rate: f64, mean_reversion: f64, volatility: f64, seed: f64, antithetic: bool) -> List {
    let run = || -> Core<List> {
        let rates = mbs::generate_hull_white_monthly_rates(
            paths.max(0) as usize, months.max(0) as usize, flat_rate, mean_reversion, volatility, seed as u64, antithetic,
        )?;
        Ok(list!(rates = rates))
    };
    outcome(run())
}
fn path_sequence(sequence: &str, brownian_bridge: bool, seed: f64) -> Core<PathSequence> {
    match sequence {
        "sobol" => Ok(PathSequence::Sobol { brownian_bridge }),
        "pseudo" if !brownian_bridge => Ok(PathSequence::Pseudo { seed: seed as u64 }),
        "pseudo" => Err(rmql::Error::InvalidInput { reason: "the Brownian bridge is only for the Sobol sequence".into() }),
        other => Err(rmql::Error::InvalidInput { reason: format!("sequence must be sobol or pseudo, not {other}") }),
    }
}
#[extendr]
fn generate_sobol_sequence(dimension: i32, points: f64) -> List {
    let run = || -> Core<List> {
        if !(points >= 1.0) || points > 1e8 {
            return Err(rmql::Error::InvalidInput { reason: format!("points must be from 1 to 1e8, not {points}") });
        }
        let dimension = dimension.max(0) as usize;
        let mut sobol = SobolSequence::new(dimension)?;
        let mut point = vec![0.0; dimension];
        let mut values = Vec::with_capacity(points as usize * dimension);
        for _ in 0..points as usize {
            sobol.next_point(&mut point);
            values.extend_from_slice(&point);
        }
        Ok(list!(values = values))
    };
    outcome(run())
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn generate_black_scholes_paths(
    spot: f64,
    rate: f64,
    dividend_yield: f64,
    volatility: f64,
    time: f64,
    steps: i32,
    paths: f64,
    sequence: &str,
    brownian_bridge: bool,
    seed: f64,
) -> List {
    let run = || -> Core<List> {
        let inputs = option_inputs([spot, spot, rate, dividend_yield, volatility, time]);
        let sequence = path_sequence(sequence, brownian_bridge, seed)?;
        let prices = longstaff_schwartz::generate_black_scholes_paths(&inputs, steps.max(0) as usize, paths.max(0.0) as usize, sequence)?;
        Ok(list!(prices = prices))
    };
    outcome(run())
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_longstaff_schwartz_value(
    option_type: &str,
    spot: f64,
    strike: f64,
    rate: f64,
    dividend_yield: f64,
    volatility: f64,
    time: f64,
    steps: i32,
    paths: f64,
    sequence: &str,
    brownian_bridge: bool,
    seed: f64,
    basis_degree: i32,
    include_payoff: bool,
    calibration: &str,
    calibration_paths: f64,
    few_in_the_money: &str,
    exercise_steps: Vec<i32>,
) -> List {
    let run = || -> Core<List> {
        let invalid = |reason: String| rmql::Error::InvalidInput { reason };
        let count = calibration_paths.max(0.0) as usize;
        let calibration = match calibration {
            "in_sample" => CalibrationPaths::InSample,
            "overlapping" => CalibrationPaths::Overlapping(count),
            "separate" => CalibrationPaths::Separate(count),
            other => return Err(invalid(format!("calibration must be in_sample, overlapping or separate, not {other}"))),
        };
        let few_in_the_money = match few_in_the_money {
            "hold" => FewInTheMoney::Hold,
            "exercise" => FewInTheMoney::Exercise,
            other => return Err(invalid(format!("few_in_the_money must be hold or exercise, not {other}"))),
        };
        if exercise_steps.iter().any(|&s| s < 1) {
            return Err(invalid("exercise steps must be positive".into()));
        }
        let settings = LongstaffSchwartzSettings {
            steps: steps.max(0) as usize,
            paths: paths.max(0.0) as usize,
            sequence: path_sequence(sequence, brownian_bridge, seed)?,
            basis_degree: basis_degree.max(0) as usize,
            include_payoff,
            calibration,
            few_in_the_money,
            exercise_steps: (!exercise_steps.is_empty()).then(|| exercise_steps.iter().map(|&s| s as usize).collect()),
        };
        let r = longstaff_schwartz::compute_longstaff_schwartz(
            names::parse_option_type(option_type)?,
            &option_inputs([spot, strike, rate, dividend_yield, volatility, time]),
            &settings,
        )?;
        let g = &r.regressions;
        Ok(list!(
            value = r.value,
            standard_error = r.standard_error,
            european_value = r.european_value,
            exercise_probability = r.exercise_probability,
            unexercised_paths = r.unexercised_paths as i32,
            dates_with_too_few_paths = r.dates_with_too_few_paths as i32,
            exercise_step = r.exercise.iter().map(|e| e.step as i32).collect::<Vec<_>>(),
            exercise_time = r.exercise.iter().map(|e| e.time).collect::<Vec<_>>(),
            exercise_paths = r.exercise.iter().map(|e| e.paths as i32).collect::<Vec<_>>(),
            step = g.iter().map(|d| d.step as i32).collect::<Vec<_>>(),
            time = g.iter().map(|d| d.time).collect::<Vec<_>>(),
            in_the_money_paths = g.iter().map(|d| d.in_the_money_paths as i32).collect::<Vec<_>>(),
            exercised_paths = g.iter().map(|d| d.exercised_paths as i32).collect::<Vec<_>>(),
            mean_immediate_value = g.iter().map(|d| d.mean_immediate_value).collect::<Vec<_>>(),
            mean_realized_continuation = g.iter().map(|d| d.mean_realized_continuation).collect::<Vec<_>>(),
            exercise_boundary = g.iter().map(|d| d.exercise_boundary.unwrap_or_else(na_real)).collect::<Vec<_>>(),
            too_few_paths = g.iter().map(|d| d.too_few_paths).collect::<Vec<_>>(),
            coefficient_counts = g.iter().map(|d| d.coefficients.as_ref().map_or(0, |c| c.len() as i32)).collect::<Vec<_>>(),
            coefficients = g.iter().flat_map(|d| d.coefficients.clone().unwrap_or_default()).collect::<Vec<_>>()
        ))
    };
    outcome(run())
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_monte_carlo_european_value(
    option_type: &str,
    spot: f64,
    strike: f64,
    rate: f64,
    dividend_yield: f64,
    volatility: f64,
    time: f64,
    paths: f64,
    seed: f64,
    antithetic: bool,
    smoothing: f64,
    threads: i32,
) -> List {
    let run = || -> Core<List> {
        let settings = MonteCarloSettings {
            paths: paths as u64,
            seed: seed as u64,
            antithetic,
            smoothing: if smoothing > 0.0 { Some(smoothing) } else { None },
            threads: threads.max(0) as usize,
        };
        let r = options::compute_monte_carlo_european(
            names::parse_option_type(option_type)?,
            &option_inputs([spot, strike, rate, dividend_yield, volatility, time]),
            &settings,
        )?;
        Ok(list!(
            value = r.value,
            standard_error = r.standard_error,
            delta = r.delta,
            gamma = r.gamma.unwrap_or_else(na_real),
            vega = r.vega,
            rho = r.rho,
            dividend_rho = r.dividend_rho,
            theta = r.theta
        ))
    };
    outcome(run())
}
// ---- calendars -------------------------------------------------------------------------------
/// 1 for a business day, 0 for a holiday, NA where the calendar fails.
#[extendr]
fn is_business_day(calendar: &str, date_serial: Vec<i32>) -> List {
    outcome(names::parse_calendar(calendar).map(|cal| {
        let rows = date_serial
            .iter()
            .map(|&d| Ok(f64::from(u8::from(cal.is_business_day(date(d)?)?))))
            .collect();
        value_list(rows)
    }))
}
#[extendr]
fn get_curve_reference_date(curve: ExternalPtr<OisCurve>) -> i32 {
    curve.curve.reference_date().serial()
}
#[extendr]
fn compute_year_fraction(day_count: &str, start: Vec<i32>, end: Vec<i32>, reference_start: Vec<i32>, reference_end: Vec<i32>) -> List {
    let dc = match names::parse_day_count(day_count) {
        Ok(dc) => dc,
        Err(e) => return failure(e),
    };
    let optional = |v: &[i32], i: usize| -> Core<Option<Date>> { if v.is_empty() { Ok(None) } else { optional_date(v[i]) } };
    let rows = (0..start.len())
        .map(|i| dc.year_fraction(date(start[i])?, date(end[i])?, optional(&reference_start, i)?, optional(&reference_end, i)?))
        .collect();
    value_list(rows)
}
fn calendar_of(name: &str) -> Core<HolidayCalendar> {
    Ok(HolidayCalendar::from(names::parse_calendar(name)?))
}
#[extendr]
fn compute_adjusted_date(calendar: &str, date_serial: Vec<i32>, convention: &str) -> List {
    let run = || -> Core<List> {
        let (cal, convention) = (calendar_of(calendar)?, names::parse_business_day_convention(convention)?);
        let rows = date_serial.iter().map(|&d| Ok(f64::from(cal.adjust(date(d)?, convention)?.serial()))).collect();
        Ok(value_list(rows))
    };
    run().unwrap_or_else(failure)
}
#[extendr]
fn compute_advanced_date(calendar: &str, date_serial: Vec<i32>, period: &str, convention: &str, end_of_month: bool) -> List {
    let run = || -> Core<List> {
        let (cal, convention, period) = (calendar_of(calendar)?, names::parse_business_day_convention(convention)?, names::parse_period(period)?);
        let rows = date_serial
            .iter()
            .map(|&d| Ok(f64::from(cal.advance(date(d)?, period, convention, end_of_month)?.serial())))
            .collect();
        Ok(value_list(rows))
    };
    run().unwrap_or_else(failure)
}
#[extendr]
fn compute_end_of_month(calendar: &str, date_serial: Vec<i32>) -> List {
    let run = || -> Core<List> {
        let cal = calendar_of(calendar)?;
        let rows = date_serial.iter().map(|&d| Ok(f64::from(cal.end_of_month(date(d)?)?.serial()))).collect();
        Ok(value_list(rows))
    };
    run().unwrap_or_else(failure)
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn generate_schedule(
    effective_date: i32,
    termination_date: i32,
    tenor: &str,
    calendar: &str,
    convention: &str,
    termination_convention: &str,
    rule: &str,
    end_of_month: bool,
    first_date: i32,
    next_to_last_date: i32,
) -> List {
    let run = || -> Core<List> {
        let s = rmql::time::generate_schedule(&ScheduleSpec {
            effective_date: date(effective_date)?,
            termination_date: date(termination_date)?,
            tenor: names::parse_period(tenor)?,
            calendar: calendar_of(calendar)?,
            convention: names::parse_business_day_convention(convention)?,
            termination_convention: names::parse_business_day_convention(termination_convention)?,
            rule: names::parse_date_generation_rule(rule)?,
            end_of_month,
            first_date: optional_date(first_date)?,
            next_to_last_date: optional_date(next_to_last_date)?,
        })?;
        Ok(list!(date = s.dates.iter().map(|d| d.serial()).collect::<Vec<i32>>(), is_regular = s.is_regular))
    };
    outcome(run())
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_cashflow_npv(
    dates: Vec<i32>,
    amounts: Vec<f64>,
    nominals: Vec<f64>,
    accruals: Vec<f64>,
    curve: ExternalPtr<OisCurve>,
    settlement_date: i32,
    include_settlement_cashflows: bool,
    npv_date: i32,
) -> List {
    let run = || -> Core<List> {
        let dates = dates.iter().map(|&d| date(d)).collect::<Core<Vec<_>>>()?;
        let v = cashflow_analysis::compute_flows_npv_bps(&dates, &amounts, &nominals, &accruals, &curve.curve, date(settlement_date)?,
                                                          include_settlement_cashflows, date(npv_date)?)?;
        Ok(list!(npv = v.npv, bps = v.bps, discount = v.discounts, flow_npv = v.npvs, flow_bps = v.bpss))
    };
    outcome(run())
}
#[extendr]
fn generate_holidays(calendar: &str, from: i32, to: i32, include_weekends: bool) -> List {
    let rows = || -> Core<List> {
        let cal = HolidayCalendar::from(names::parse_calendar(calendar)?);
        let list = cal.holidays(date(from)?, date(to)?, include_weekends)?;
        Ok(list!(
            value = list.iter().map(|d| d.serial()).collect::<Vec<i32>>()
        ))
    };
    outcome(rows())
}
// ---- parallel batches --------------------------------------------------------------------
//
// The inputs are converted here on R's main thread, and the results are converted back here after
// the threads have finished. `rmql::batch` receives plain Rust values only; the core crate does
// not depend on extendr, so the threads cannot call the R API.
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_bond_values_batch(
    settlement_days: Vec<i32>,
    face_amount: Vec<f64>,
    effective_date: Vec<i32>,
    termination_date: Vec<i32>,
    tenor: Vec<String>,
    calendar: Vec<String>,
    convention: Vec<String>,
    termination_convention: Vec<String>,
    rule: Vec<String>,
    end_of_month: Vec<i32>,
    coupon_rate: Vec<f64>,
    day_count: Vec<String>,
    payment_convention: Vec<String>,
    redemption: Vec<f64>,
    issue_date: Vec<i32>,
    rate: Vec<f64>,
    yield_day_count: Vec<String>,
    compounding: Vec<String>,
    frequency: Vec<i32>,
    evaluation_date: Vec<i32>,
    threads: i32,
) -> List {
    let run = || -> Core<List> {
        let units = (0..rate.len())
            .map(|i| {
                Ok(BondEvaluation {
                    spec: FixedRateBondSpec {
                        settlement_days: settlement_days[i] as u32,
                        face_amount: face_amount[i],
                        schedule: ScheduleSpec {
                            effective_date: date(effective_date[i])?,
                            termination_date: date(termination_date[i])?,
                            tenor: names::parse_period(&tenor[i])?,
                            calendar: HolidayCalendar::from(names::parse_calendar(&calendar[i])?),
                            convention: names::parse_business_day_convention(&convention[i])?,
                            termination_convention: names::parse_business_day_convention(
                                &termination_convention[i],
                            )?,
                            rule: names::parse_date_generation_rule(&rule[i])?,
                            end_of_month: flag(end_of_month[i])?,
                            first_date: None,
                            next_to_last_date: None,
                        },
                        coupon_rate: coupon_rate[i],
                        day_count: names::parse_day_count(&day_count[i])?,
                        payment_convention: names::parse_business_day_convention(&payment_convention[i])?,
                        redemption: redemption[i],
                        issue_date: Some(date(issue_date[i])?),
                        payment_calendar: None,
                    },
                    rate: rate[i],
                    convention: yield_convention(
                        &yield_day_count[i],
                        &compounding[i],
                        frequency[i],
                    )?,
                    evaluation_date: date(evaluation_date[i])?,
                })
            })
            .collect::<Core<Vec<_>>>()?;
        let rows = batch::compute_bond_values_batch(&units, threads as usize)?;
        let pick = |f: fn(&batch::BondValues) -> f64| -> Vec<f64> {
            rows.iter()
                .map(|r| r.as_ref().map_or(na_real(), f))
                .collect()
        };
        let errors: Vec<String> = rows
            .iter()
            .map(|r| r.as_ref().err().map_or(String::new(), |e| e.to_string()))
            .collect();
        Ok(list!(
            settlement_date = pick(|r| r.settlement_date.serial() as f64),
            clean_price = pick(|r| r.clean_price),
            dirty_price = pick(|r| r.dirty_price),
            accrued_amount = pick(|r| r.accrued_amount),
            duration_modified = pick(|r| r.duration_modified),
            convexity = pick(|r| r.convexity),
            basis_point_value = pick(|r| r.basis_point_value),
            yield_value_basis_point = pick(|r| r.yield_value_basis_point),
            error = errors
        ))
    };
    outcome(run())
}
fn first_error(values: [&Core<f64>; 3]) -> String {
    values
        .iter()
        .find_map(|v| v.as_ref().err().map(|e| e.to_string()))
        .unwrap_or_default()
}
/// Instruments and dates are columns with the 1-based number of their curve.
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_curve_values_batch(
    evaluation_date: Vec<i32>,
    reference_date: Vec<i32>,
    index: Vec<String>,
    curve_day_count: Vec<String>,
    interpolation: Vec<String>,
    accuracy: Vec<f64>,
    instrument_curve: Vec<i32>,
    tenor: Vec<String>,
    rate: Vec<f64>,
    settlement_days: Vec<i32>,
    payment_frequency: Vec<i32>,
    payment_lag: Vec<i32>,
    date_curve: Vec<i32>,
    date_serial: Vec<i32>,
    threads: i32,
) -> List {
    let run = || -> Core<List> {
        let mut units = Vec::with_capacity(evaluation_date.len());
        for c in 0..evaluation_date.len() {
            let number = c as i32 + 1;
            let instruments = (0..tenor.len())
                .filter(|&i| instrument_curve[i] == number)
                .map(|i| {
                    Ok(if tenor[i] == "ON" {
                        OisCurveInstrument::OvernightDeposit { rate: rate[i] }
                    } else {
                        OisCurveInstrument::Ois {
                            tenor: names::parse_period(&tenor[i])?,
                            rate: rate[i],
                            settlement_days: settlement_days[i] as u32,
                            payment_frequency: payment_frequency[i] as u32,
                            payment_lag: payment_lag[i] as u32,
                        }
                    })
                })
                .collect::<Core<Vec<_>>>()?;
            let dates = (0..date_serial.len())
                .filter(|&i| date_curve[i] == number)
                .map(|i| date(date_serial[i]))
                .collect::<Core<Vec<_>>>()?;
            units.push(CurveEvaluation {
                spec: OisCurveSpec {
                    evaluation_date: date(evaluation_date[c])?,
                    reference_date: date(reference_date[c])?,
                    index: names::parse_overnight_index(&index[c])?,
                    curve_day_count: names::parse_day_count(&curve_day_count[c])?,
                    instruments,
                    interpolation: names::parse_ois_interpolation(&interpolation[c])?,
                    accuracy: accuracy[c],
                },
                dates,
                day_count: names::parse_day_count(&curve_day_count[c])?,
            });
        }
        let results = batch::compute_curve_values_batch(&units, threads as usize)?;
        let (mut curve, mut serial, mut errors) = (Vec::new(), Vec::new(), Vec::new());
        let (mut discount, mut zero, mut forward, mut worst) =
            (Vec::new(), Vec::new(), Vec::new(), Vec::new());
        for (c, result) in results.iter().enumerate() {
            match result {
                Ok(values) => {
                    let max_error = values
                        .quote_repricing
                        .iter()
                        .filter_map(|q| q.implied_rate.map(|v| (v - q.rate).abs()))
                        .fold(0.0_f64, f64::max);
                    for p in &values.points {
                        curve.push(c as i32 + 1);
                        serial.push(p.date.serial());
                        discount.push(p.discount.as_ref().map_or(na_real(), |v| *v));
                        zero.push(p.zero_continuous.as_ref().map_or(na_real(), |v| *v));
                        forward.push(p.forward_1d_simple.as_ref().map_or(na_real(), |v| *v));
                        worst.push(max_error);
                        errors.push(first_error([
                            &p.discount,
                            &p.zero_continuous,
                            &p.forward_1d_simple,
                        ]));
                    }
                }
                Err(e) => {
                    curve.push(c as i32 + 1);
                    serial.push(0);
                    discount.push(na_real());
                    zero.push(na_real());
                    forward.push(na_real());
                    worst.push(na_real());
                    errors.push(e.to_string());
                }
            }
        }
        Ok(list!(
            curve = curve,
            date = serial,
            discount = discount,
            zero_continuous = zero,
            forward_1d_simple = forward,
            max_reproduction_error = worst,
            error = errors
        ))
    };
    outcome(run())
}
/// A deliberate panic, for the test that a defect stays visible and does not end the R session.
#[extendr]
fn panic_for_test() {
    panic!("rmql deliberate panic for the test");
}
// The module has the name of the R package, because R looks for its routines by that name.
// ---- portfolio (docs/spec_portfolio.md) -------------------------------------------------------------------

fn portfolio_inputs<'a>(returns: &'a [f64], assets: i32, weight_sum: f64, lower: Vec<f64>, upper: Vec<f64>) -> (ReturnMatrix<'a>, PortfolioConstraints) {
    (ReturnMatrix { values: returns, assets: assets.max(0) as usize }, PortfolioConstraints { weight_sum, lower, upper })
}
/// `parameters`: risk aversion, risk-free rate, confidence level, target return, target volatility.
fn portfolio_method(method: &str, parameters: &[f64], budget: Vec<f64>) -> Core<PortfolioMethod> {
    let p = |i: usize| parameters.get(i).copied().unwrap_or(f64::NAN);
    Ok(match method {
        "minimum_variance" => PortfolioMethod::MinimumVariance,
        "mean_variance" => PortfolioMethod::MeanVariance { risk_aversion: p(0) },
        "maximum_return" => PortfolioMethod::MaximumReturn,
        "maximum_sharpe" => PortfolioMethod::MaximumSharpe { risk_free_rate: p(1) },
        "minimum_ES" => PortfolioMethod::MinimumExpectedShortfall { confidence_level: p(2) },
        "risk_budget" => PortfolioMethod::RiskBudget { budget },
        "target_return" => PortfolioMethod::TargetReturn { target: p(3) },
        "target_risk" => PortfolioMethod::TargetVolatility { target: p(4) },
        other => return Err(rmql::Error::InvalidInput { reason: format!("unknown portfolio method `{other}`") }),
    })
}
fn optimal_portfolio_list(p: &OptimalPortfolio) -> List {
    list!(
        weights = p.weights.clone(),
        expected_return = p.expected_return,
        volatility = p.volatility,
        objective = p.objective,
        at_lower = p.at_lower.clone(),
        at_upper = p.at_upper.clone(),
        solver = p.solver,
        iterations = p.iterations as i32,
        stationarity_residual = p.stationarity_residual
    )
}
/// Returns come by rows: period 1's assets, then period 2's.
#[extendr]
fn compute_return_moments(returns: Vec<f64>, assets: i32) -> List {
    let run = || -> Core<List> {
        let m = portfolio::compute_return_moments(&ReturnMatrix { values: &returns, assets: assets.max(0) as usize })?;
        Ok(list!(mean = m.mean, covariance = m.covariance.concat(), periods = m.periods as i32))
    };
    outcome(run())
}
#[extendr]
fn check_portfolio_constraints(assets: i32, weight_sum: f64, lower: Vec<f64>, upper: Vec<f64>) -> List {
    outcome(PortfolioConstraints { weight_sum, lower, upper }.check(assets.max(0) as usize).map(|_| list!(valid = true)))
}
#[extendr]
fn compute_optimal_portfolio(returns: Vec<f64>, assets: i32, weight_sum: f64, lower: Vec<f64>, upper: Vec<f64>, method: &str, parameters: Vec<f64>, budget: Vec<f64>) -> List {
    let run = || -> Core<List> {
        let (r, c) = portfolio_inputs(&returns, assets, weight_sum, lower, upper);
        let method = portfolio_method(method, &parameters, budget)?;
        Ok(optimal_portfolio_list(&portfolio::compute_optimal_portfolio(&r, &c, &method)?))
    };
    outcome(run())
}
#[extendr]
fn compute_efficient_frontier(returns: Vec<f64>, assets: i32, weight_sum: f64, lower: Vec<f64>, upper: Vec<f64>, targets: Vec<f64>) -> List {
    let run = || -> Core<List> {
        let (r, c) = portfolio_inputs(&returns, assets, weight_sum, lower, upper);
        let points = portfolio::compute_efficient_frontier(&r, &c, &targets)?;
        Ok(list!(
            expected_return = points.iter().map(|p| p.expected_return).collect::<Vec<f64>>(),
            volatility = points.iter().map(|p| p.volatility).collect::<Vec<f64>>(),
            weights = points.iter().flat_map(|p| p.weights.clone()).collect::<Vec<f64>>(),
            stationarity_residual = points.iter().map(|p| p.stationarity_residual).collect::<Vec<f64>>()
        ))
    };
    outcome(run())
}
#[extendr]
fn compute_portfolio_risk(returns: Vec<f64>, assets: i32, weights: Vec<f64>, confidence_level: f64) -> List {
    let run = || -> Core<List> {
        let r = portfolio::compute_portfolio_risk(&ReturnMatrix { values: &returns, assets: assets.max(0) as usize }, &weights, confidence_level)?;
        Ok(list!(
            expected_return = r.expected_return,
            volatility = r.volatility,
            normal_var = r.normal_var,
            normal_es = r.normal_es,
            historical_var = r.historical_var,
            historical_es = r.historical_es,
            tail_mean_es = r.tail_mean_es,
            volatility_contribution = r.volatility_contribution,
            normal_var_contribution = r.normal_var_contribution,
            normal_es_contribution = r.normal_es_contribution,
            historical_es_contribution = r.historical_es_contribution
        ))
    };
    outcome(run())
}

// ---- market VaR and backtests (docs/spec_market_risk.md) ----------------------------------------------------

#[extendr]
fn compute_loss_risk(losses: Vec<f64>, confidence_levels: Vec<f64>) -> List {
    let run = || -> Core<List> {
        let r: Vec<market_risk::LossRisk> = confidence_levels.iter().map(|&a| market_risk::compute_loss_risk(&losses, a)).collect::<Core<_>>()?;
        let col = |f: fn(&market_risk::LossRisk) -> f64| r.iter().map(f).collect::<Vec<f64>>();
        Ok(list!(
            confidence_level = col(|x| x.confidence_level),
            gaussian_var = col(|x| x.gaussian_var),
            gaussian_es = col(|x| x.gaussian_es),
            historical_var = col(|x| x.historical_var),
            historical_var_type1 = col(|x| x.historical_var_type1),
            tail_mean_es = col(|x| x.tail_mean_es),
            historical_es = col(|x| x.historical_es)
        ))
    };
    outcome(run())
}
/// The covariance comes by rows.
#[extendr]
fn compute_monte_carlo_risk(weights: Vec<f64>, mean: Vec<f64>, covariance: Vec<f64>, confidence_level: f64, scenarios: f64, seed: f64, batches: i32, threads: i32) -> List {
    let run = || -> Core<List> {
        let n = mean.len();
        if covariance.len() != n * n {
            return Err(rmql::Error::InvalidInput { reason: "the covariance must be a square matrix of the size of the mean".into() });
        }
        let cov: Vec<Vec<f64>> = covariance.chunks(n.max(1)).map(|r| r.to_vec()).collect();
        if !(scenarios >= 1.0 && scenarios.fract() == 0.0 && seed >= 0.0 && seed.fract() == 0.0) {
            return Err(rmql::Error::InvalidInput { reason: "the scenarios and the seed must be whole numbers".into() });
        }
        let settings = market_risk::MonteCarloSettings { scenarios: scenarios as usize, seed: seed as u64, batches: batches.max(0) as usize, threads: threads.max(0) as usize };
        let r = market_risk::compute_monte_carlo_risk(&weights, &mean, &cov, confidence_level, &settings)?;
        Ok(list!(var = r.var, es = r.es, var_standard_error = r.var_standard_error, es_standard_error = r.es_standard_error, scenarios = r.scenarios as f64))
    };
    outcome(run())
}
#[extendr]
fn compute_var_backtest(losses: Vec<f64>, var: Vec<f64>, confidence_level: f64) -> List {
    let run = || -> Core<List> {
        let b = market_risk::compute_var_backtest(&losses, &var, confidence_level)?;
        Ok(list!(
            observations = b.observations as i32,
            exceptions = b.exceptions as i32,
            exception_rate = b.exception_rate,
            expected_rate = b.expected_rate,
            kupiec_lr = b.kupiec_lr,
            kupiec_p_value = b.kupiec_p_value,
            n00 = b.n00 as i32,
            n01 = b.n01 as i32,
            n10 = b.n10 as i32,
            n11 = b.n11 as i32,
            independence_lr = b.independence_lr,
            independence_p_value = b.independence_p_value,
            conditional_coverage_lr = b.conditional_coverage_lr,
            conditional_coverage_p_value = b.conditional_coverage_p_value
        ))
    };
    outcome(run())
}
#[extendr]
fn compute_rolling_var(losses: Vec<f64>, window: i32, confidence_level: f64, method: &str) -> List {
    let run = || -> Core<List> {
        let method = match method {
            "historical" => market_risk::RollingMethod::Historical,
            "gaussian" => market_risk::RollingMethod::Gaussian,
            other => return Err(rmql::Error::InvalidInput { reason: format!("unknown rolling method `{other}`") }),
        };
        Ok(list!(var = market_risk::compute_rolling_var(&losses, window.max(0) as usize, confidence_level, method)?))
    };
    outcome(run())
}
#[extendr]
fn compute_traffic_light(exceptions: Vec<i32>, observations: i32, confidence_level: f64) -> List {
    let run = || -> Core<List> {
        let r: Vec<(market_risk::TrafficLight, f64)> = exceptions
            .iter()
            .map(|&k| market_risk::compute_traffic_light(k.max(0) as usize, observations.max(0) as usize, confidence_level))
            .collect::<Core<_>>()?;
        let zone = |z: market_risk::TrafficLight| match z {
            market_risk::TrafficLight::Green => "green",
            market_risk::TrafficLight::Yellow => "yellow",
            market_risk::TrafficLight::Red => "red",
        };
        Ok(list!(zone = r.iter().map(|x| zone(x.0)).collect::<Vec<&str>>(), cumulative_probability = r.iter().map(|x| x.1).collect::<Vec<f64>>()))
    };
    outcome(run())
}

// ---- credit portfolio, ASRF and IRB (docs/spec_credit_risk.md) ----------------------------------------------

fn obligors_of(pd: &[f64], ead: &[f64], lgd: &[f64], rho: &[f64]) -> Core<Vec<credit_risk::Obligor>> {
    let n = pd.len();
    if [ead.len(), lgd.len(), rho.len()].iter().any(|&m| m != n) {
        return Err(rmql::Error::InvalidInput { reason: "PD, EAD, LGD and rho must have one value per obligor".into() });
    }
    Ok((0..n).map(|i| credit_risk::Obligor { pd: pd[i], ead: ead[i], lgd: lgd[i], rho: rho[i] }).collect())
}
#[extendr]
fn compute_conditional_pd(pd: Vec<f64>, rho: Vec<f64>, z: Vec<f64>) -> List {
    let run = || -> Core<List> {
        if pd.len() != rho.len() || pd.len() != z.len() {
            return Err(rmql::Error::InvalidInput { reason: "PD, rho and z must have the same length".into() });
        }
        if pd.iter().any(|p| !(*p > 0.0 && *p < 1.0)) || rho.iter().any(|r| !(0.0..1.0).contains(r)) {
            return Err(rmql::Error::InvalidInput { reason: "PD must be in (0, 1) and rho in [0, 1)".into() });
        }
        Ok(list!(value = (0..pd.len()).map(|i| credit_risk::compute_conditional_pd(pd[i], rho[i], z[i])).collect::<Vec<f64>>()))
    };
    outcome(run())
}
#[extendr]
fn compute_credit_loss_distribution(pd: Vec<f64>, ead: Vec<f64>, lgd: Vec<f64>, rho: Vec<f64>, unit: f64, panels: i32) -> List {
    let run = || -> Core<List> {
        let d = credit_risk::compute_credit_loss_distribution(&obligors_of(&pd, &ead, &lgd, &rho)?, unit, panels.max(0) as usize)?;
        Ok(list!(probability = d.probability.clone(), mean = d.mean(), standard_deviation = d.standard_deviation()))
    };
    outcome(run())
}
#[extendr]
fn compute_distribution_risk(probability: Vec<f64>, unit: f64, confidence_levels: Vec<f64>) -> List {
    let run = || -> Core<List> {
        if probability.is_empty() || probability.iter().any(|p| !(*p >= 0.0) || !p.is_finite()) {
            return Err(rmql::Error::InvalidInput { reason: "the probabilities must be finite and non-negative".into() });
        }
        let d = credit_risk::CreditLossDistribution { unit, probability };
        let r: Vec<credit_risk::DistributionRisk> = confidence_levels.iter().map(|&a| credit_risk::compute_distribution_risk(&d, a)).collect::<Core<_>>()?;
        Ok(list!(
            var = r.iter().map(|x| x.var).collect::<Vec<f64>>(),
            es = r.iter().map(|x| x.es).collect::<Vec<f64>>(),
            tail_mean_es = r.iter().map(|x| x.tail_mean_es).collect::<Vec<f64>>()
        ))
    };
    outcome(run())
}
#[extendr]
fn simulate_credit_losses(pd: Vec<f64>, ead: Vec<f64>, lgd: Vec<f64>, rho: Vec<f64>, scenarios: f64, seed: f64, threads: i32) -> List {
    let run = || -> Core<List> {
        if !(scenarios >= 1.0 && scenarios.fract() == 0.0 && seed >= 0.0 && seed.fract() == 0.0) {
            return Err(rmql::Error::InvalidInput { reason: "the scenarios and the seed must be whole numbers".into() });
        }
        let losses = credit_risk::simulate_credit_losses(&obligors_of(&pd, &ead, &lgd, &rho)?, scenarios as usize, seed as u64, threads.max(0) as usize)?;
        Ok(list!(loss = losses))
    };
    outcome(run())
}
#[extendr]
fn compute_asrf_var(pd: Vec<f64>, ead: Vec<f64>, lgd: Vec<f64>, rho: Vec<f64>, confidence_levels: Vec<f64>) -> List {
    let run = || -> Core<List> {
        let o = obligors_of(&pd, &ead, &lgd, &rho)?;
        Ok(list!(var = confidence_levels.iter().map(|&a| credit_risk::compute_asrf_var(&o, a)).collect::<Core<Vec<f64>>>()?))
    };
    outcome(run())
}
#[extendr]
fn compute_irb_capital(pd: Vec<f64>, lgd: Vec<f64>, maturity: Vec<f64>, ead: Vec<f64>) -> List {
    let run = || -> Core<List> {
        let n = pd.len();
        if [lgd.len(), maturity.len(), ead.len()].iter().any(|&m| m != n) {
            return Err(rmql::Error::InvalidInput { reason: "PD, LGD, maturity and EAD must have the same length".into() });
        }
        let c: Vec<credit_risk::IrbCapital> = (0..n).map(|i| credit_risk::compute_irb_capital(pd[i], lgd[i], maturity[i], ead[i])).collect::<Core<_>>()?;
        Ok(list!(
            correlation = c.iter().map(|x| x.correlation).collect::<Vec<f64>>(),
            maturity_adjustment = c.iter().map(|x| x.maturity_adjustment).collect::<Vec<f64>>(),
            capital = c.iter().map(|x| x.capital).collect::<Vec<f64>>(),
            risk_weighted_assets = c.iter().map(|x| x.risk_weighted_assets).collect::<Vec<f64>>()
        ))
    };
    outcome(run())
}

// ---- credit tranches and CMO (docs/spec_tranching.md) -------------------------------------------------------

#[extendr]
fn compute_tranche_loss(loss_rate: Vec<f64>, attachment: f64, detachment: f64) -> List {
    let run = || -> Core<List> {
        if !(0.0..1.0).contains(&attachment) || !(detachment > attachment && detachment <= 1.0) {
            return Err(rmql::Error::InvalidInput { reason: format!("a tranche needs 0 <= A < D <= 1, not A = {attachment}, D = {detachment}") });
        }
        Ok(list!(value = loss_rate.iter().map(|l| tranche::compute_tranche_loss(*l, attachment, detachment)).collect::<Vec<f64>>()))
    };
    outcome(run())
}
#[extendr]
fn compute_tranche_risk(probability: Vec<f64>, unit: f64, total: f64, attachment: Vec<f64>, detachment: Vec<f64>, confidence_level: f64) -> List {
    let run = || -> Core<List> {
        if attachment.len() != detachment.len() {
            return Err(rmql::Error::InvalidInput { reason: "one detachment per attachment".into() });
        }
        let d = credit_risk::CreditLossDistribution { unit, probability };
        let r: Vec<tranche::TrancheRisk> = attachment.iter().zip(&detachment).map(|(a, b)| tranche::compute_tranche_risk(&d, total, *a, *b, confidence_level)).collect::<Core<_>>()?;
        Ok(list!(
            expected_tranche_loss = r.iter().map(|x| x.expected_tranche_loss).collect::<Vec<f64>>(),
            hit_probability = r.iter().map(|x| x.hit_probability).collect::<Vec<f64>>(),
            wipeout_probability = r.iter().map(|x| x.wipeout_probability).collect::<Vec<f64>>(),
            var = r.iter().map(|x| x.var).collect::<Vec<f64>>()
        ))
    };
    outcome(run())
}
#[extendr]
fn compute_lhp_expected_tranche_loss(pd: f64, lgd: f64, rho: f64, attachment: Vec<f64>, detachment: Vec<f64>, panels: i32) -> List {
    let run = || -> Core<List> {
        if attachment.len() != detachment.len() {
            return Err(rmql::Error::InvalidInput { reason: "one detachment per attachment".into() });
        }
        let v = attachment.iter().zip(&detachment).map(|(a, b)| tranche::compute_lhp_expected_tranche_loss(pd, lgd, rho, *a, *b, panels.max(1) as usize)).collect::<Core<Vec<f64>>>()?;
        Ok(list!(value = v))
    };
    outcome(run())
}
#[extendr]
fn compute_tranche_legs(hazard: Vec<f64>, ead: Vec<f64>, lgd: Vec<f64>, rho: Vec<f64>, unit: f64, times: Vec<f64>, discount_rate: f64, attachment: f64, detachment: f64, panels: i32) -> List {
    let run = || -> Core<List> {
        let n = hazard.len();
        if [ead.len(), lgd.len(), rho.len()].iter().any(|&m| m != n) {
            return Err(rmql::Error::InvalidInput { reason: "hazard, EAD, LGD and rho must have one value per obligor".into() });
        }
        let o: Vec<tranche::HazardObligor> = (0..n).map(|i| tranche::HazardObligor { hazard: hazard[i], ead: ead[i], lgd: lgd[i], rho: rho[i] }).collect();
        let l = tranche::compute_tranche_legs(&o, unit, &times, discount_rate, attachment, detachment, panels.max(1) as usize)?;
        Ok(list!(
            expected_tranche_loss = l.expected_tranche_loss,
            discount = l.discount,
            premium_per_unit_spread = l.premium_per_unit_spread,
            loss_leg = l.loss_leg,
            fair_spread = l.fair_spread
        ))
    };
    outcome(run())
}
fn cmo_list(c: &tranche::CmoCashflows) -> List {
    list!(
        interest = c.interest.concat(),
        principal = c.principal.concat(),
        accrued = c.accrued.concat(),
        balance = c.balance.concat(),
        residual = c.residual.clone(),
        weighted_average_life = c.weighted_average_life()
    )
}
#[extendr]
fn compute_sequential_cmo(principal: Vec<f64>, interest: Vec<f64>, balances: Vec<f64>, coupons: Vec<f64>, z_last: bool) -> List {
    let run = || -> Core<List> {
        if balances.len() != coupons.len() {
            return Err(rmql::Error::InvalidInput { reason: "one coupon per tranche".into() });
        }
        let t: Vec<tranche::CmoTranche> = balances.iter().zip(&coupons).map(|(b, c)| tranche::CmoTranche { balance: *b, coupon: *c }).collect();
        Ok(cmo_list(&tranche::compute_sequential_cmo(&principal, &interest, &t, z_last)?))
    };
    outcome(run())
}
#[extendr]
fn compute_pac_support_cmo(principal: Vec<f64>, interest: Vec<f64>, schedule: Vec<f64>, balances: Vec<f64>, coupons: Vec<f64>) -> List {
    let run = || -> Core<List> {
        if balances.len() != 2 || coupons.len() != 2 {
            return Err(rmql::Error::InvalidInput { reason: "a PAC and a support tranche: two balances and two coupons".into() });
        }
        let t = |k: usize| tranche::CmoTranche { balance: balances[k], coupon: coupons[k] };
        Ok(cmo_list(&tranche::compute_pac_support_cmo(&principal, &interest, &schedule, t(0), t(1))?))
    };
    outcome(run())
}

// ---- total return swaps -------------------------------------------------------------------------
/// The periods of a TRS leg. A negative payment lag means that the leg has no payment terms.
#[allow(clippy::too_many_arguments)]
fn trs_periods(
    effective_date: i32,
    termination_date: i32,
    frequency: i32,
    calendar: &str,
    period_convention: &str,
    rule: &str,
    end_of_month: bool,
    payment_calendar: &str,
    payment_convention: &str,
    payment_lag: i32,
) -> Core<trs::TrsPeriodSpec> {
    Ok(trs::TrsPeriodSpec {
        effective_date: date(effective_date)?,
        termination_date: date(termination_date)?,
        frequency: frequency as u32,
        calendar: calendar_of(calendar)?,
        period_convention: names::parse_business_day_convention(period_convention)?,
        rule: names::parse_date_generation_rule(rule)?,
        end_of_month,
        payment: if payment_lag < 0 {
            None
        } else {
            Some(trs::PaymentTerms {
                calendar: calendar_of(payment_calendar)?,
                convention: names::parse_business_day_convention(payment_convention)?,
                lag: payment_lag as u32,
            })
        },
    })
}
fn serial_or_zero(d: Option<Date>) -> i32 {
    d.map(|x| x.serial()).unwrap_or(0)
}
fn optional_value(x: Option<f64>) -> f64 {
    x.unwrap_or_else(na_real)
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn create_trs_funding_leg(
    effective_date: i32,
    termination_date: i32,
    frequency: i32,
    calendar: &str,
    period_convention: &str,
    rule: &str,
    end_of_month: bool,
    payment_calendar: &str,
    payment_convention: &str,
    payment_lag: i32,
    index: &str,
    day_count: &str,
    notional: f64,
    spread: f64,
    lookback: i32,
    reset_relative_to: &str,
    fixing_offset: i32,
    fixing_calendar: &str,
    fixing_convention: &str,
) -> List {
    let build = || -> Core<trs::TrsFundingLeg> {
        if lookback < 0 {
            return Err(rmql::Error::InvalidInput { reason: "the lookback must not be negative".into() });
        }
        trs::create_trs_funding_leg(trs::TrsFundingLegSpec {
            periods: trs_periods(effective_date, termination_date, frequency, calendar, period_convention, rule, end_of_month,
                                 payment_calendar, payment_convention, payment_lag)?,
            index: names::parse_overnight_index(index)?,
            day_count: names::parse_day_count(day_count)?,
            notional,
            spread,
            lookback: lookback as u32,
            reset_relative_to: match reset_relative_to {
                "period_start" => trs::ResetRelativeTo::PeriodStart,
                "period_end" => trs::ResetRelativeTo::PeriodEnd,
                other => return Err(rmql::Error::InvalidInput { reason: format!("unknown reset date rule: {other}") }),
            },
            fixing_offset,
            fixing_calendar: calendar_of(fixing_calendar)?,
            fixing_convention: names::parse_business_day_convention(fixing_convention)?,
        })
    };
    outcome(build().map(|leg| list!(value = ExternalPtr::new(leg))))
}
#[extendr]
fn get_trs_funding_schedule(leg: ExternalPtr<trs::TrsFundingLeg>) -> List {
    let p = &leg.periods;
    list!(
        unadjusted_start = p.iter().map(|x| x.period.unadjusted_start.serial()).collect::<Vec<i32>>(),
        unadjusted_end = p.iter().map(|x| x.period.unadjusted_end.serial()).collect::<Vec<i32>>(),
        accrual_start = p.iter().map(|x| x.period.start.serial()).collect::<Vec<i32>>(),
        accrual_end = p.iter().map(|x| x.period.end.serial()).collect::<Vec<i32>>(),
        reset_date = p.iter().map(|x| x.reset_date.serial()).collect::<Vec<i32>>(),
        fixing_date = p.iter().map(|x| x.fixing_date.serial()).collect::<Vec<i32>>(),
        observation_start = p.iter().map(|x| x.observation_start.serial()).collect::<Vec<i32>>(),
        observation_end = p.iter().map(|x| x.observation_end.serial()).collect::<Vec<i32>>(),
        payment_date = p.iter().map(|x| serial_or_zero(x.period.payment_date)).collect::<Vec<i32>>(),
        accrual = p.iter().map(|x| x.accrual).collect::<Vec<f64>>(),
        business_days = p.iter().map(|x| x.days.len() as i32).collect::<Vec<i32>>()
    )
}
/// The daily observation of one period: each business day, its fixing date and its weight.
#[extendr]
fn get_trs_funding_observations(leg: ExternalPtr<trs::TrsFundingLeg>) -> List {
    let mut period = Vec::new();
    let (mut day, mut fixing_date, mut weight) = (Vec::new(), Vec::new(), Vec::new());
    for (k, p) in leg.periods.iter().enumerate() {
        for i in 0..p.days.len() {
            period.push(k as i32 + 1);
            day.push(p.days[i].serial());
            fixing_date.push(p.observation_dates[i].serial());
            weight.push(p.day_fractions[i]);
        }
    }
    list!(period = period, day = day, fixing_date = fixing_date, day_fraction = weight)
}
#[extendr]
fn compute_trs_funding_cashflows(
    leg: ExternalPtr<trs::TrsFundingLeg>,
    curve: Robj,
    evaluation_date: i32,
    fixing_dates: Vec<i32>,
    fixing_rates: Vec<f64>,
) -> List {
    let run = || -> Core<List> {
        let fixings = fixings_of(&fixing_dates, &fixing_rates)?;
        let curve: Option<ExternalPtr<OisCurve>> = if curve.is_null() {
            None
        } else {
            let c = ExternalPtr::<OisCurve>::try_from(curve)
                .map_err(|_| rmql::Error::InvalidInput { reason: "the curve is not an OIS curve".into() })?;
            if c.spec.index != leg.spec.index {
                return Err(rmql::Error::InvalidInput { reason: "the curve is not of the leg's overnight index".into() });
            }
            Some(c)
        };
        let a = trs::compute_trs_funding_amounts(&leg, date(evaluation_date)?, &fixings, curve.as_ref().map(|c| &c.curve));
        Ok(list!(
            status = a.iter().map(|x| x.status.name()).collect::<Vec<&str>>(),
            compounded_rate = a.iter().map(|x| optional_value(x.compounded_rate)).collect::<Vec<f64>>(),
            amount = a.iter().map(|x| optional_value(x.amount)).collect::<Vec<f64>>(),
            fixed_days = a.iter().map(|x| x.fixed_days as i32).collect::<Vec<i32>>(),
            projected_days = a.iter().map(|x| x.projected_days as i32).collect::<Vec<i32>>(),
            days = a.iter().map(|x| x.days as i32).collect::<Vec<i32>>(),
            reason = a.iter().map(|x| x.reason.clone()).collect::<Vec<String>>()
        ))
    };
    outcome(run())
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn create_trs_return_leg(
    effective_date: i32,
    termination_date: i32,
    frequency: i32,
    calendar: &str,
    period_convention: &str,
    rule: &str,
    end_of_month: bool,
    payment_calendar: &str,
    payment_convention: &str,
    payment_lag: i32,
    notional: f64,
    initial_price: f64,
    valuation_relative_to: &str,
    valuation_offset: i32,
    valuation_calendar: &str,
    valuation_convention: &str,
    final_valuation_date: i32,
) -> List {
    let build = || -> Core<trs::TrsReturnLeg> {
        trs::create_trs_return_leg(trs::TrsReturnLegSpec {
            periods: trs_periods(effective_date, termination_date, frequency, calendar, period_convention, rule, end_of_month,
                                 payment_calendar, payment_convention, payment_lag)?,
            notional,
            initial_price,
            valuation_relative_to: match valuation_relative_to {
                "payment_date" => trs::ValuationRelativeTo::PaymentDate,
                "period_end" => trs::ValuationRelativeTo::PeriodEnd,
                other => return Err(rmql::Error::InvalidInput { reason: format!("unknown valuation date rule: {other}") }),
            },
            valuation_offset,
            valuation_calendar: calendar_of(valuation_calendar)?,
            valuation_convention: names::parse_business_day_convention(valuation_convention)?,
            final_valuation_date: optional_date(final_valuation_date)?,
        })
    };
    outcome(build().map(|leg| list!(value = ExternalPtr::new(leg))))
}
#[extendr]
fn get_trs_return_schedule(leg: ExternalPtr<trs::TrsReturnLeg>) -> List {
    let p = &leg.periods;
    list!(
        unadjusted_start = p.iter().map(|x| x.period.unadjusted_start.serial()).collect::<Vec<i32>>(),
        unadjusted_end = p.iter().map(|x| x.period.unadjusted_end.serial()).collect::<Vec<i32>>(),
        period_start = p.iter().map(|x| x.period.start.serial()).collect::<Vec<i32>>(),
        period_end = p.iter().map(|x| x.period.end.serial()).collect::<Vec<i32>>(),
        start_valuation_date = p.iter().map(|x| serial_or_zero(x.start_valuation_date)).collect::<Vec<i32>>(),
        valuation_date = p.iter().map(|x| x.valuation_date.serial()).collect::<Vec<i32>>(),
        valuation_date_by_rule = p.iter().map(|x| x.valuation_date_by_rule.serial()).collect::<Vec<i32>>(),
        payment_date = p.iter().map(|x| serial_or_zero(x.period.payment_date)).collect::<Vec<i32>>()
    )
}
#[extendr]
fn compute_trs_return_cashflows(
    leg: ExternalPtr<trs::TrsReturnLeg>,
    level_dates: Vec<i32>,
    levels: Vec<f64>,
    level_kinds: Vec<String>,
) -> List {
    let run = || -> Core<List> {
        let mut map = std::collections::BTreeMap::new();
        for ((&d, &l), k) in level_dates.iter().zip(&levels).zip(&level_kinds) {
            let kind = match k.as_str() {
                "observed" => trs::LevelKind::Observed,
                "scenario" => trs::LevelKind::Scenario,
                other => return Err(rmql::Error::InvalidInput { reason: format!("unknown level kind: {other}") }),
            };
            if map.insert(date(d)?, (l, kind)).is_some() {
                return Err(rmql::Error::InvalidInput { reason: "a level date is given twice".into() });
            }
        }
        let a = trs::compute_trs_return_amounts(&leg, &map);
        Ok(list!(
            status = a.iter().map(|x| x.status.name()).collect::<Vec<&str>>(),
            start_level = a.iter().map(|x| optional_value(x.start_level)).collect::<Vec<f64>>(),
            end_level = a.iter().map(|x| optional_value(x.end_level)).collect::<Vec<f64>>(),
            period_return = a.iter().map(|x| optional_value(x.period_return)).collect::<Vec<f64>>(),
            amount = a.iter().map(|x| optional_value(x.amount)).collect::<Vec<f64>>(),
            reason = a.iter().map(|x| x.reason.clone()).collect::<Vec<String>>()
        ))
    };
    outcome(run())
}

// ---- IRRBB interest rate shock scenarios (SRP31.90-31.93) ----------------------------------------------
fn irrbb_sizes(parallel_bp: f64, short_bp: f64, long_bp: f64) -> irrbb::IrrbbShockSizes {
    irrbb::IrrbbShockSizes { parallel: parallel_bp / 1e4, short: short_bp / 1e4, long: long_bp / 1e4 }
}
/// "base" means no shock: the base curve rebuilt on the same dates.
fn irrbb_scenario(name: &str) -> Core<Option<irrbb::IrrbbScenario>> {
    if name == "base" { Ok(None) } else { irrbb::IrrbbScenario::parse(name).map(Some) }
}
#[extendr]
fn get_irrbb_shock_sizes(currency: &str) -> List {
    outcome(irrbb::get_irrbb_shock_sizes(currency).map(|s| list!(parallel_bp = s.parallel * 1e4, short_bp = s.short * 1e4, long_bp = s.long * 1e4)))
}
#[extendr]
fn compute_irrbb_shocks(times: Vec<f64>, scenario: &str, parallel_bp: f64, short_bp: f64, long_bp: f64, x: f64) -> List {
    let run = || -> Core<List> {
        let s = irrbb::IrrbbScenario::parse(scenario)?;
        let sizes = irrbb_sizes(parallel_bp, short_bp, long_bp);
        let shocks = times.iter().map(|&t| irrbb::compute_irrbb_shock(t, s, &sizes, x).map(|v| v * 1e4)).collect::<Core<Vec<f64>>>()?;
        Ok(list!(shock_bp = shocks))
    };
    outcome(run())
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn compute_irrbb_curve_points(
    curve: ExternalPtr<OisCurve>,
    scenario: &str,
    dates: Vec<i32>,
    parallel_bp: f64,
    short_bp: f64,
    long_bp: f64,
    x: f64,
    floor: Vec<f64>,
) -> List {
    let run = || -> Core<List> {
        let dates = dates.iter().map(|&d| date(d)).collect::<Core<Vec<_>>>()?;
        let p = irrbb::compute_irrbb_curve_points(&curve.curve, irrbb_scenario(scenario)?, &irrbb_sizes(parallel_bp, short_bp, long_bp), x,
                                                  floor.first().copied(), &dates)?;
        Ok(list!(
            date = p.iter().map(|q| q.date.serial()).collect::<Vec<i32>>(),
            time = p.iter().map(|q| q.time).collect::<Vec<f64>>(),
            base_zero = p.iter().map(|q| q.base_zero).collect::<Vec<f64>>(),
            shock = p.iter().map(|q| q.shock).collect::<Vec<f64>>(),
            shocked_zero = p.iter().map(|q| q.shocked_zero).collect::<Vec<f64>>(),
            floored = p.iter().map(|q| q.floored).collect::<Vec<bool>>()
        ))
    };
    outcome(run())
}
#[extendr]
#[allow(clippy::too_many_arguments)]
fn create_irrbb_shocked_curve(
    curve: ExternalPtr<OisCurve>,
    scenario: &str,
    dates: Vec<i32>,
    parallel_bp: f64,
    short_bp: f64,
    long_bp: f64,
    x: f64,
    floor: Vec<f64>,
) -> List {
    let run = || -> Core<OisCurve> {
        let dates = dates.iter().map(|&d| date(d)).collect::<Core<Vec<_>>>()?;
        let shocked = irrbb::create_irrbb_shocked_curve(&curve.curve, irrbb_scenario(scenario)?, &irrbb_sizes(parallel_bp, short_bp, long_bp), x,
                                                        floor.first().copied(), &dates)?;
        Ok(OisCurve::given(shocked, curve.spec.index.clone()))
    };
    outcome(run().map(|c| list!(value = ExternalPtr::new(c))))
}

extendr_module! {
    mod rmql;
    fn get_irrbb_shock_sizes;
    fn compute_irrbb_shocks;
    fn compute_irrbb_curve_points;
    fn create_irrbb_shocked_curve;
    fn create_trs_funding_leg;
    fn get_trs_funding_schedule;
    fn get_trs_funding_observations;
    fn compute_trs_funding_cashflows;
    fn create_trs_return_leg;
    fn get_trs_return_schedule;
    fn compute_trs_return_cashflows;
    fn create_fixed_rate_bond;
    fn compute_settlement_date;
    fn compute_bond_values;
    fn compute_duration;
    fn compute_yield_from_price;
    fn create_ois_swap;
    fn compute_ois_swap_dates;
    fn compute_ois_swap_value;
    fn compute_ois_swap_cashflows;
    fn compute_ois_swap_daily_rates;
    fn compute_ois_swap_quote_sensitivity;
    fn get_bond_cashflows;
    fn compute_bond_value_with_zero_spread;
    fn compute_z_spread_from_price;
    fn compute_bond_value_on_curve;
    fn compute_yield_sensitivity;
    fn compute_curve_node_sensitivity;
    fn compute_quote_sensitivity;
    fn compute_ois_asset_swap;
    fn compute_asset_swap_quote_sensitivity;
    fn compute_yen_asset_swap;
    fn compute_yen_asset_swap_on_basis_curve;
    fn bootstrap_xccy_curve;
    fn create_ctd_curve;
    fn compute_ctd_time_value;
    fn compute_future_basis;
    fn compute_hull_white_bond_option_value;
    fn compute_hull_white_swaption_value;
    fn compute_hull_white_bermudan_swaption_value;
    fn compute_hull_white_callable_bond_value;
    fn compute_hull_white_callable_bond_decisions;
    fn compute_sabr_volatility;
    fn calibrate_hull_white;
    fn calibrate_sabr;
    fn create_credit_default_swap;
    fn create_hazard_curve;
    fn create_survival_probability_curve;
    fn compute_survival_probability;
    fn compute_hazard_rate;
    fn compute_cds_value;
    fn bootstrap_hazard_curve;
    fn compute_cds_quote_sensitivity;
    fn compute_cds_maturity;
    fn compute_prdc_value;
    fn compute_prdc_three_factor_value;
    fn calibrate_prdc_fx_volatility;
    fn compute_fx_delta_conversion;
    fn compute_fx_smile_values;
    fn compute_prdc_smile_value;
    fn compute_european_option_value;
    fn compute_barrier_option_value;
    fn compute_binomial_option_value;
    fn compute_american_approximation_value;
    fn compute_forward_option_value;
    fn compute_implied_volatility;
    fn compute_monte_carlo_european_value;
    fn compute_caplet_value;
    fn compute_backward_caplet_value;
    fn compute_backward_forward_rate;
    fn compute_backward_period_state;
    fn create_exponential_correlation;
    fn create_reduced_correlation;
    fn compute_lmm_monte_carlo;
    fn generate_lmm_paths;
    fn compute_rebonato_swaption_volatility;
    fn calibrate_lmm_correlation;
    fn calibrate_lmm_volatilities;
    fn compute_lmm_bermudan_swaption;
    fn compute_caplet_from_normals;
    fn compute_correlated_normals;
    fn generate_correlated_normals;
    fn check_mbs_pass_through;
    fn compute_mbs_cashflows;
    fn compute_mbs_path_values;
    fn compute_mbs_oas;
    fn generate_hull_white_monthly_rates;
    fn compute_return_moments;
    fn check_portfolio_constraints;
    fn compute_optimal_portfolio;
    fn compute_efficient_frontier;
    fn compute_portfolio_risk;
    fn compute_loss_risk;
    fn compute_monte_carlo_risk;
    fn compute_var_backtest;
    fn compute_rolling_var;
    fn compute_traffic_light;
    fn compute_conditional_pd;
    fn compute_credit_loss_distribution;
    fn compute_distribution_risk;
    fn simulate_credit_losses;
    fn compute_asrf_var;
    fn compute_irb_capital;
    fn compute_tranche_loss;
    fn compute_tranche_risk;
    fn compute_lhp_expected_tranche_loss;
    fn compute_tranche_legs;
    fn compute_sequential_cmo;
    fn compute_pac_support_cmo;
    fn generate_sobol_sequence;
    fn generate_black_scholes_paths;
    fn compute_longstaff_schwartz_value;
    fn compute_remaining_years;
    fn compute_price_from_simple_rate;
    fn compute_simple_rate_from_price;
    fn compute_price_from_compound_yield;
    fn compute_compound_yield_from_price;
    fn compute_risk_from_simple_rate;
    fn compute_risk_from_compound_yield;
    fn bootstrap_ois_curve;
    fn with_extrapolation;
    fn compute_discount;
    fn compute_zero_rate;
    fn compute_forward_rate;
    fn get_quote_repricing;
    fn get_discount_nodes;
    fn create_flat_curve;
    fn create_zero_curve;
    fn create_discount_curve;
    fn create_zero_spreaded_curve;
    fn bootstrap_bond_curve;
    fn is_business_day;
    fn get_curve_reference_date;
    fn compute_year_fraction;
    fn compute_adjusted_date;
    fn compute_advanced_date;
    fn compute_end_of_month;
    fn generate_schedule;
    fn compute_cashflow_npv;
    fn generate_holidays;
    fn compute_bond_values_batch;
    fn compute_curve_values_batch;
    fn panic_for_test;
}
